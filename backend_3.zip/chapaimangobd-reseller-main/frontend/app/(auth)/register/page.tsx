'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ApiError, errorMessage, fieldErrors } from '@/lib/api';
import { useAppDispatch } from '@/lib/store/hooks';
import { sessionApi } from '@/lib/store/endpoints/session';
import { useRegisterMutation, useSendRegisterOtpMutation } from '@/lib/store/endpoints/public';
import { t } from '@/lib/i18n/bn';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/form';
import { PhoneField } from '@/components/ui/phone-field';
import { PasswordField } from '@/components/ui/password-field';
import { OtpField, ResendCode, useResendCountdown } from '@/components/ui/otp-field';
import { Alert } from '@/components/ui/layout';

/**
 * Registration in two steps: the phone proves itself by SMS before the account
 * exists (docs/adr/0014), then the code, name and password create it.
 *
 * The phone comes first because it is the step that can fail for reasons
 * outside the form, a number already registered or an SMS that cannot go out,
 * and finding that out after typing a name and a password is finding it out late.
 */
export default function RegisterPage() {
  const router = useRouter();
  const dispatch = useAppDispatch();

  const [step, setStep] = useState<'phone' | 'details'>('phone');
  const [sentAt, setSentAt] = useState<number | null>(null);
  const [form, setForm] = useState({ name: '', shopName: '', phone: '', password: '', otp: '' });
  const set = (key: keyof typeof form) => (value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const secondsLeft = useResendCountdown(sentAt);

  // Errors are read from each mutation's state and shown on the form.
  const [sendCodeTrigger, sendCode] = useSendRegisterOtpMutation();
  const [registerTrigger, register] = useRegisterMutation();

  const submitPhone = async () => {
    try {
      await sendCodeTrigger({ phone: form.phone }).unwrap();
      setSentAt(Date.now());
      setStep('details');
    } catch {
      // Shown on the form.
    }
  };

  const resend = () => {
    sendCodeTrigger({ phone: form.phone })
      .unwrap()
      .then(() => setSentAt(Date.now()))
      .catch(() => undefined);
  };

  const submitDetails = async () => {
    try {
      await registerTrigger({
        name: form.name,
        phone: form.phone,
        password: form.password,
        otp: form.otp,
        ...(form.shopName ? { shopName: form.shopName } : {}),
      }).unwrap();
      /*
       * The register response omits the features block, so the session is read
       * fresh rather than seeded with half of itself, and read before leaving,
       * so the dashboard's shell does not see the signed-out answer and bounce
       * back to /login.
       */
      const request = dispatch(
        sessionApi.endpoints.getSession.initiate(undefined, { forceRefetch: true })
      );
      await request
        .unwrap()
        .catch(() => undefined)
        .finally(() => request.unsubscribe());
      /*
       * The dashboard, not the KYC page. A new account is never asked to verify
       * (docs/adr/0017), so that page would have nothing on it; the setup
       * checklist on the dashboard is what a new reseller actually needs.
       */
      router.replace('/reseller');
    } catch {
      // Shown on the form.
    }
  };

  if (step === 'phone') {
    const errors = fieldErrors(sendCode.error);
    const generalError =
      sendCode.error instanceof ApiError && !sendCode.error.fields ? errorMessage(sendCode.error) : null;

    return (
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void submitPhone();
        }}
      >
        <h1 className="mb-1 text-xl font-bold">{t('auth.registerTitle')}</h1>
        <p className="mb-6 text-sm text-muted-foreground">{t('auth.registerStepPhone')}</p>

        {generalError && <Alert tone="danger">{generalError}</Alert>}

        <PhoneField
          id="phone"
          label={t('auth.phone')}
          value={form.phone}
          onChange={set('phone')}
          error={errors.phone}
          required
        />

        <Button type="submit" full size="lg" loading={sendCode.isLoading}>
          {t('auth.sendCode')}
        </Button>

        <p className="mt-5 text-center text-sm text-muted-foreground">
          {t('auth.hasAccount')}{' '}
          <Link href="/login" className="font-semibold text-primary-ink hover:underline">
            {t('auth.login')}
          </Link>
        </p>
      </form>
    );
  }

  const errors = fieldErrors(register.error);
  const generalError =
    register.error instanceof ApiError && (!register.error.fields || register.error.code === 'PHONE_TAKEN')
      ? errorMessage(register.error)
      : null;
  const resendError = sendCode.error ? errorMessage(sendCode.error) : null;

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        void submitDetails();
      }}
    >
      <h1 className="mb-1 text-xl font-bold">{t('auth.registerTitle')}</h1>
      <p className="mb-2 text-sm text-muted-foreground">{t('auth.registerStepDetails')}</p>
      <p className="mb-6 text-sm">
        <span className="tabular font-medium">{t('auth.otpSentTo').replace('{phone}', form.phone)}</span>{' '}
        <button
          type="button"
          onClick={() => {
            register.reset();
            sendCode.reset();
            setStep('phone');
          }}
          className="font-semibold text-primary-ink hover:underline"
        >
          {t('auth.changeNumber')}
        </button>
      </p>

      {generalError && <Alert tone="danger">{generalError}</Alert>}
      {resendError && <Alert tone="danger">{resendError}</Alert>}

      <OtpField id="otp" value={form.otp} onChange={set('otp')} error={errors.otp} className="mb-2" />
      <ResendCode
        secondsLeft={secondsLeft}
        pending={sendCode.isLoading}
        onResend={resend}
      />

      <Field label={t('auth.name')} htmlFor="name" error={errors.name} required>
        <Input
          id="name"
          value={form.name}
          onChange={(event) => set('name')(event.target.value)}
          autoComplete="name"
          required
        />
      </Field>

      <Field label={t('auth.shopName')} htmlFor="shopName" hint={t('app.optional')} error={errors.shopName}>
        <Input id="shopName" value={form.shopName} onChange={(event) => set('shopName')(event.target.value)} />
      </Field>

      <PasswordField
        id="password"
        label={t('auth.password')}
        autoComplete="new-password"
        hint={t('auth.passwordHint')}
        minLength={6}
        value={form.password}
        onChange={set('password')}
        error={errors.password}
        required
      />

      <Button type="submit" full size="lg" loading={register.isLoading}>
        {t('auth.register')}
      </Button>
    </form>
  );
}
