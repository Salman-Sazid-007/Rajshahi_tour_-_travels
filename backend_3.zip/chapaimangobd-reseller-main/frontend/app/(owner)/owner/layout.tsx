'use client';

import {
  BadgeCheck,
  Boxes,
  ChartColumn,
  HandCoins,
  ClipboardList,
  Contact,
  LayoutDashboard,
  LayoutTemplate,
  MapPin,
  MessageSquare,
  MessageSquareWarning,
  Package,
  Receipt,
  ScrollText,
  ShoppingCart,
  Settings,
  Store,
  UserCog,
  Users,
  Wallet,
} from 'lucide-react';
import { skipToken } from '@reduxjs/toolkit/query/react';
import { useSession } from '@/lib/session';
import { LIST, LIVE } from '@/lib/store/api';
import { useRefreshOnRise } from '@/lib/store/live';
import { useGetDashboardQuery } from '@/lib/store/endpoints/dashboard';
import { useGetNotificationsInfiniteQuery } from '@/lib/store/endpoints/notifications';
import { AppShell, type NavItem } from '@/components/app-shell';

/**
 * Every owner destination, four of which reach the bottom bar on a phone. The
 * inbox is not in the list: it is the bell in the top bar.
 *
 * The four are the ones touched every day: the day's numbers, the fulfilment
 * queue, the catalog behind it, and the money waiting for a decision. Setup
 * screens that are visited once a season, sources and zones among them, sit
 * behind More rather than competing for a thumb.
 *
 * The sections only mean anything in the sidebar, where all of them are visible
 * at once and an unbroken column that long would be a wall. The order still has
 * to put the daily four first, because that is what the bottom bar slices off.
 */
const NAV: NavItem[] = [
  { href: '/owner', labelKey: 'nav.dashboard', icon: LayoutDashboard, section: 'nav.groupDaily' },
  { href: '/owner/orders', labelKey: 'nav.orders', icon: ClipboardList, section: 'nav.groupDaily' },
  { href: '/owner/products', labelKey: 'nav.products', icon: Package, section: 'nav.groupDaily' },
  {
    href: '/owner/finance',
    labelKey: 'nav.finance',
    shortLabelKey: 'nav.financeShort',
    icon: Wallet,
    section: 'nav.groupDaily',
  },
  { href: '/owner/resellers', labelKey: 'nav.resellers', icon: Users, section: 'nav.groupMoney' },
  { href: '/owner/customers', labelKey: 'nav.customers', icon: Contact, section: 'nav.groupMoney' },
  { href: '/owner/kyc', labelKey: 'nav.kyc', icon: BadgeCheck, section: 'nav.groupMoney' },
  /*
   * What customers said was wrong. Sits with the money rather than with setup
   * because it is read, worked through and closed out like the other queues,
   * not configured once a season.
   */
  {
    href: '/owner/complaints',
    labelKey: 'complaint.title',
    icon: MessageSquareWarning,
    section: 'nav.groupMoney',
  },
  /*
   * The cost side (PLAN-3). With the money rather than with setup, because these
   * are worked through like the other queues — a purchase is recorded the day the
   * crates arrive and a payee is paid when there is cash — not configured once a
   * season. None of the four goes near the bottom bar: that is the daily four
   * above, and adding to it would push something out.
   */
  { href: '/owner/purchases', labelKey: 'nav.purchases', icon: ShoppingCart, section: 'nav.groupMoney' },
  { href: '/owner/payees', labelKey: 'nav.payees', icon: HandCoins, section: 'nav.groupMoney' },
  { href: '/owner/expenses', labelKey: 'nav.expenses', icon: Receipt, section: 'nav.groupMoney' },
  { href: '/owner/reports', labelKey: 'nav.reports', icon: ChartColumn, section: 'nav.groupMoney' },
  /*
   * Inventory sits in setup: the items themselves are defined once, and the
   * day-to-day movement happens through a purchase or a delivery rather than here.
   */
  { href: '/owner/supplies', labelKey: 'nav.supplies', icon: Boxes, section: 'nav.groupSetup' },
  { href: '/owner/sources', labelKey: 'nav.sources', icon: Store, section: 'nav.groupSetup' },
  // The content every reseller's public page is drawn from.
  { href: '/owner/landing', labelKey: 'nav.landing', icon: LayoutTemplate, section: 'nav.groupSetup' },
  { href: '/owner/zones', labelKey: 'nav.zones', icon: MapPin, section: 'nav.groupSetup' },
  /*
   * SMS sits in setup because it is configured once, but it is the one setup
   * screen with a control the owner may need in a hurry: the master switch that
   * stops every message the platform would send.
   */
  { href: '/owner/sms', labelKey: 'nav.sms', icon: MessageSquare, section: 'nav.groupSetup' },
  { href: '/owner/settings', labelKey: 'nav.settings', icon: Settings, section: 'nav.groupSetup' },
  // Who changed what. Read when something needs explaining, so it sits with setup.
  { href: '/owner/audit', labelKey: 'nav.audit', icon: ScrollText, section: 'nav.groupSetup' },
  { href: '/owner/account', labelKey: 'nav.account', icon: UserCog, section: 'nav.groupSetup' },
];

export default function OwnerLayout({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();
  // No background reads while a temporary password is still in use: the API
  // refuses them (PASSWORD_CHANGE_REQUIRED) and the shell is on its way to Account.
  const ready = Boolean(session) && !session?.user.mustChangePassword;

  /*
   * Every badge from one request. The dashboard payload already counts what is
   * waiting on the owner (orders to accept, deposits and withdrawals to decide,
   * KYC to review, complaints to close), and the dashboard page polls the same
   * cache entry, so the badges cost nothing extra there and one request
   * a minute everywhere else, instead of a list query per badge. Gated on the
   * session because the layout renders before the redirect to /login, and an
   * ungated query would fire a guaranteed 401 on the way out.
   */
  const { data: counts } = useGetDashboardQuery(ready ? undefined : skipToken, LIVE);

  // Only the count is wanted, so one row is asked for; `unread` rides on the page.
  const { data: inbox } = useGetNotificationsInfiniteQuery(
    ready ? { role: 'owner', limit: 1 } : skipToken,
    LIVE
  );

  /*
   * The queues themselves are not polled: these two small requests are, and a
   * rise in a count refreshes the lists behind it. See lib/store/live.ts.
   */
  useRefreshOnRise(
    counts
      ? [
          counts.awaitingAcceptance,
          counts.agingOrders,
          counts.pendingDeposits,
          counts.pendingWithdrawals,
          counts.pendingKyc,
          counts.openComplaints,
        ]
      : undefined,
    [
      { type: 'Order', id: LIST },
      'OrderSummary',
      { type: 'Deposit', id: LIST },
      { type: 'Withdrawal', id: LIST },
      { type: 'Kyc', id: LIST },
      { type: 'Complaint', id: LIST },
    ]
  );
  const unread = inbox?.pages[0]?.unread;
  useRefreshOnRise(unread === undefined ? undefined : [unread], [{ type: 'Notification', id: LIST }]);

  const badges: Partial<Record<string, number>> = {
    // A confirmed order is one the reseller committed to and nobody has touched.
    '/owner/orders': counts?.awaitingAcceptance,
    '/owner/finance': counts ? counts.pendingDeposits + counts.pendingWithdrawals : undefined,
    '/owner/kyc': counts?.pendingKyc,
    '/owner/complaints': counts?.openComplaints,
  };

  const nav = NAV.map((item) =>
    badges[item.href] ? { ...item, badge: badges[item.href] } : item
  );

  return (
    <AppShell
      role="owner"
      nav={nav}
      notificationsHref="/owner/notifications"
      notificationCount={inbox?.pages[0]?.unread ?? 0}
    >
      {children}
    </AppShell>
  );
}
