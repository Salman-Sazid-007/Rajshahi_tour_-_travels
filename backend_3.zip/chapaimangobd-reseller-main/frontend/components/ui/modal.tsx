'use client';

import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { t } from '@/lib/i18n/bn';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

/**
 * A bottom sheet on a phone, a centred dialog from `sm` up.
 *
 * It looked like a sheet before and behaved like a div. What it now does is the
 * part users feel rather than see:
 *
 * - Focus enters the sheet and cannot Tab out behind it, and goes back where it
 *   came from on close.
 * - iOS Safari ignores `overflow: hidden` on the body, so the page is pinned by
 *   position instead and the scroll offset is restored afterwards.
 * - The header and footer stay put while the body scrolls. The Confirm button on
 *   an order is the point of the screen and was reachable only by scrolling to
 *   the bottom of it.
 * - Dismissal is guarded when `dirty` is set: backdrop, Escape, swipe, the X and
 *   the footer's `<ModalCancel />`. A tap on the backdrop used to discard a
 *   half-filled deposit form, screenshot and all, and later the X and the
 *   footer's Cancel, which sit under the thumb next to Save, did the same.
 * - Sized against the dynamic viewport, so on Android the keyboard shrinks the
 *   sheet instead of covering its footer.
 *
 * Mount a sheet only while it is open, or key it by the record it edits, so
 * what was typed for one order can never be submitted for the next.
 */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  footerLead,
  wide,
  dirty,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  /** Pinned above the footer buttons: the numbers a decision depends on. */
  footerLead?: React.ReactNode;
  wide?: boolean;
  /** Set when the sheet holds unsaved input, to guard backdrop, Escape and swipe. */
  dirty?: boolean;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [confirmingClose, setConfirmingClose] = useState(false);
  const [dragY, setDragY] = useState(0);
  const dragStart = useRef<number | null>(null);

  /*
   * The latest `dirty` and `onClose`, read when a dismissal happens rather than
   * baked into the effect below. The effect pins the page and moves focus, so
   * re-running it whenever a parent re-rendered with a new `onClose`, or a field
   * became dirty on its first keystroke, pulled focus out of the field being
   * typed in and closed the phone's keyboard after one character.
   */
  const latest = useRef({ dirty, onClose });
  useLayoutEffect(() => {
    latest.current = { dirty, onClose };
  });

  /** Every dismissal path goes through here, so `dirty` guards all of them. */
  const requestClose = useCallback(() => {
    if (latest.current.dirty) {
      setConfirmingClose(true);
      return;
    }
    latest.current.onClose();
  }, []);

  useEffect(() => {
    if (!open) return undefined;

    const previouslyFocused = document.activeElement as HTMLElement | null;

    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        requestClose();
        return;
      }

      if (event.key !== 'Tab') return;

      const panel = panelRef.current;
      if (!panel) return;

      const focusable = panel.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', onKey, true);

    /*
     * `overflow: hidden` on the body is not enough on iOS, which keeps scrolling
     * the page behind the sheet. Pinning by position works everywhere, at the
     * cost of having to put the reader back where they were.
     */
    const { body } = document;
    const scrollY = window.scrollY;
    const saved = {
      position: body.style.position,
      top: body.style.top,
      width: body.style.width,
      overflow: body.style.overflow,
    };

    body.style.position = 'fixed';
    body.style.top = `-${scrollY}px`;
    body.style.width = '100%';
    body.style.overflow = 'hidden';

    // Focus the panel rather than its first control: an autofocused text input
    // on a phone opens the keyboard over the content the user came to read. A
    // field that asked for focus on purpose (the amount on a payment) keeps it.
    const panel = panelRef.current;
    if (panel && !panel.contains(document.activeElement)) panel.focus();

    return () => {
      document.removeEventListener('keydown', onKey, true);
      body.style.position = saved.position;
      body.style.top = saved.top;
      body.style.width = saved.width;
      body.style.overflow = saved.overflow;
      window.scrollTo(0, scrollY);
      previouslyFocused?.focus?.();
    };
  }, [open, requestClose]); // `requestClose` is stable: this runs on open and close only.

  if (!open) return null;

  return (
    <ModalCloseContext.Provider value={requestClose}>
      <div
        className="fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center sm:p-4"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onMouseDown={(event) => {
          if (event.target === event.currentTarget) requestClose();
        }}
      >
        <div
          ref={panelRef}
          tabIndex={-1}
          style={dragY ? { transform: `translateY(${dragY}px)` } : undefined}
          className={cn(
            'sheet-in card elev-3 relative flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-b-none rounded-t-2xl border-0 p-0 outline-none sm:max-h-[85dvh] sm:rounded-2xl',
            wide ? 'sm:max-w-2xl' : 'sm:max-w-md'
          )}
        >
          <header
            className="shrink-0 bg-surface"
            onTouchStart={(event) => {
              dragStart.current = event.touches[0].clientY;
            }}
            onTouchMove={(event) => {
              if (dragStart.current === null) return;
              // Downward only. Dragging a sheet up past its own top looks broken.
              const delta = event.touches[0].clientY - dragStart.current;
              if (delta > 0) setDragY(delta);
            }}
            onTouchEnd={() => {
              // A quarter of the way down is a dismissal; anything less snaps back.
              if (dragY > 120) requestClose();
              setDragY(0);
              dragStart.current = null;
            }}
          >
            {/* The grab handle, which is also the affordance that says "drag me". */}
            <div className="flex justify-center pt-2 sm:hidden">
              <span aria-hidden className="h-1 w-10 rounded-full bg-input" />
            </div>

            <div className="flex items-center justify-between gap-3 px-5 pb-3 pt-4 sm:px-6 sm:pt-5">
              <h2 className="min-w-0 truncate text-lg font-semibold tracking-tight">{title}</h2>
              <button
                type="button"
                onClick={requestClose}
                aria-label={t('app.close')}
                className="-mr-2 flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </header>

          {/* A little more room than the header and footer, because this is the
            * part that is read rather than scanned. */}
          <div className="flex-1 overflow-y-auto overscroll-contain px-5 pb-5 pt-1 sm:px-6">
            {children}
          </div>

          {(footer || footerLead) && (
            <div className="shrink-0 border-t border-border bg-surface px-5 pt-4 pb-safe-4 sm:px-6">
              {footerLead && <div className="mb-3">{footerLead}</div>}
              {/* Full width and side by side on a phone, where a corner button is a stretch. */}
              {footer && (
                <div className="flex gap-3 [&>button]:flex-1 sm:justify-end sm:[&>button]:flex-none">
                  {footer}
                </div>
              )}
            </div>
          )}

          {confirmingClose && (
            <div className="fade-in absolute inset-0 z-10 flex flex-col justify-end bg-black/40 sm:justify-center sm:p-6">
              <div className="card elev-3 m-0 rounded-b-none rounded-t-2xl border-0 px-5 pt-5 pb-safe-5 sm:rounded-2xl sm:pb-5">
                <p className="font-medium">{t('app.unsavedTitle')}</p>
                <p className="mt-1 text-sm text-muted-foreground">{t('app.unsavedHelp')}</p>
                <div className="mt-5 flex gap-3 [&>button]:flex-1">
                  <Button variant="outline" onClick={() => setConfirmingClose(false)}>
                    {t('app.keepEditing')}
                  </Button>
                  <Button variant="danger" onClick={onClose}>
                    {t('app.discard')}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ModalCloseContext.Provider>
  );
}

const ModalCloseContext = createContext<() => void>(() => {});

/**
 * The guarded close, for anything inside a sheet that dismisses it: the
 * footer's Cancel, a "done" link. Goes through the unsaved-changes check.
 */
export function useModalClose(): () => void {
  return useContext(ModalCloseContext);
}

/**
 * The footer's dismiss button. Use this rather than a Button wired to `onClose`
 * so a half-filled form asks before it is thrown away.
 *
 * Next to a destructive action (reject, cancel an order, void) pass
 * `label={t('app.dismiss')}`, "ফিরে যান", so the two buttons never share a word.
 */
export function ModalCancel({ label, disabled }: { label?: string; disabled?: boolean }) {
  const close = useModalClose();
  return (
    <Button variant="outline" onClick={close} disabled={disabled}>
      {label ?? t('app.cancel')}
    </Button>
  );
}
