'use client';

import { useMemo, useState } from 'react';
import { CircleCheck } from 'lucide-react';
import { ApiError, errorMessage, fieldErrors } from '@/lib/api';
import { usePlaceShopOrderMutation } from '@/lib/store/endpoints/public';
import { t } from '@/lib/i18n/bn';
import { formatMoney, formatNumber } from '@/lib/format';
import type { DeliveryZone, PaymentMode, PublicShop } from '@/lib/types';
import { Alert, Badge, Card, StickyBar } from '@/components/ui/layout';
import { Button, ButtonLink } from '@/components/ui/button';
import { useToast } from '@/components/ui/toast';
import { QuantityStepper } from '@/components/ui/stepper';
import { Field, Input, Select, Textarea } from '@/components/ui/form';
import { DistrictSelect } from '@/components/ui/district-field';
import { PhoneField } from '@/components/ui/phone-field';
import { ProductThumb } from '@/components/ui/product-image';

/**
 * One line of the order: a box, and how many of them.
 *
 * Keyed by the box rather than the product, because two elevens and three sixes
 * of the same mango is two lines and is the whole point. See docs/adr/0021.
 */
type Line = { product: string; variant: string; quantity: number };

/** The submit button lives outside the form, in the bar pinned to the viewport. */
const FORM_ID = 'shop-order-form';
const PRODUCTS_ID = 'order-products';

export function OrderForm({
  slug,
  shop,
  zones,
}: {
  slug: string;
  shop: PublicShop;
  zones: DeliveryZone[];
}) {
  /**
   * Generated once when the form mounts and sent with the order. Disabling the
   * submit button is not a guard: mobile Chrome on a flaky connection retries the
   * POST itself, and the server uses this to return the first order instead of
   * creating a second one.
   */
  const [submissionId] = useState(() => crypto.randomUUID());

  const [lines, setLines] = useState<Record<string, number>>({});
  const [customer, setCustomer] = useState({
    name: '',
    phone: '',
    address: '',
    district: '',
    note: '',
  });
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('cod');
  const [placed, setPlaced] = useState<string | null>(null);

  const districts = useMemo(
    () => zones.flatMap((zone) => zone.districts.map((d) => ({ district: d, charge: zone.charge }))),
    [zones]
  );
  /** The districts this shop actually delivers to, as the picker marks them. */
  const deliverableDistricts = useMemo(() => districts.map((d) => d.district), [districts]);

  const deliveryCharge = districts.find((d) => d.district === customer.district)?.charge ?? 0;

  /*
   * Every box on offer, flattened once, so a line can find its product and its
   * price without two nested searches at every call site.
   */
  const boxes = useMemo(
    () =>
      shop.products.flatMap((product) =>
        product.variants.map((variant) => ({ product, variant }))
      ),
    [shop.products]
  );
  const boxById = useMemo(
    () => new Map(boxes.map((box) => [box.variant.id, box])),
    [boxes]
  );

  const selected: Line[] = Object.entries(lines)
    .filter(([, quantity]) => quantity > 0)
    .map(([variant, quantity]) => ({
      product: boxById.get(variant)?.product.id ?? '',
      variant,
      quantity,
    }))
    .filter((line) => line.product);

  // Only priced boxes can be totalled. A hidden-price line shows no figure,
  // which is the point of hiding it.
  const anyHidden = selected.some((line) => boxById.get(line.variant)?.product.priceHidden);

  const itemsTotal = selected.reduce((sum, line) => {
    const box = boxById.get(line.variant);
    return sum + (box?.variant.price ?? 0) * line.quantity;
  }, 0);

  const toast = useToast();
  const [placeOrder, submit] = usePlaceShopOrderMutation();

  const send = async () => {
    try {
      const data = await placeOrder({
        slug,
        submissionId,
        paymentMode,
        customer: {
          name: customer.name,
          phone: customer.phone,
          address: customer.address,
          district: customer.district,
          ...(customer.note ? { note: customer.note } : {}),
        },
        items: selected,
      }).unwrap();
      setPlaced(data.orderCode);
    } catch (error) {
      // The button is pinned to the bottom and the error alert sits above the products.
      toast(errorMessage(error), 'danger');
    }
  };

  if (placed) {
    return (
      <Card className="text-center">
        <CircleCheck className="mx-auto mb-3 h-12 w-12 text-success" />
        <h2 className="mb-2 text-lg font-semibold">{t('shop.orderPlaced')}</h2>
        <p className="mb-5 text-sm text-muted-foreground">{t('shop.orderPlacedHelp')}</p>

        <p className="mb-1 text-sm text-muted-foreground">{t('order.code')}</p>
        <p className="tabular mb-6 text-3xl font-semibold">{placed}</p>

        <ButtonLink href={`/track?code=${placed}`} variant="outline" full size="lg">
          {t('shop.trackOrder')}
        </ButtonLink>
      </Card>
    );
  }

  const errors = fieldErrors(submit.error);
  // In Bengali from the error code, never the server's English sentence. A shop
  // closed between loading the page and pressing the button answers
  // 409 SHOP_NOT_ACCEPTING, which reads as exactly that.
  const generalError =
    submit.error instanceof ApiError && !submit.error.fields ? errorMessage(submit.error) : null;

  const set =
    (key: keyof typeof customer) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setCustomer((prev) => ({ ...prev, [key]: e.target.value }));

  return (
    <>
      <form
        id={FORM_ID}
        onSubmit={(event) => {
          event.preventDefault();
          void send();
        }}
      >
        {generalError && <Alert tone="danger">{generalError}</Alert>}

        <div id={PRODUCTS_ID} className="mb-6 scroll-mt-24 space-y-3">
          {shop.products.map((product) => {
            // Any box of this product chosen lights the whole card.
            const chosen = product.variants.reduce(
              (sum, variant) => sum + (lines[variant.id] ?? 0),
              0
            );

            return (
              <Card
                key={product.id}
                className={chosen > 0 ? 'ring-2 ring-primary' : undefined}
              >
                <div className="flex items-start gap-3">
                  {/*
                   * A mango shop with no photographs of mangoes was asking people
                   * to buy fruit from a spreadsheet. The largest thumb on offer,
                   * because this is the only screen where the photograph is the
                   * thing being sold rather than a row marker.
                   */}
                  <ProductThumb images={product.images} alt={product.name} size="lg" />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-medium">{product.name}</h3>
                      {!product.inStock && <Badge tone="danger">{t('catalog.outOfStock')}</Badge>}
                    </div>

                    {/* The landing designs set the price colour; the fallback is the old mango ink. */}
                    <p className="mt-0.5 font-semibold text-[var(--lp-price,oklch(0.45_0.14_70))]">
                      {product.priceHidden
                        ? t('shop.priceOnCall')
                        : t('catalog.fromPrice').replace(
                            '{amount}',
                            formatMoney(
                              Math.min(...product.variants.map((v) => v.price ?? 0))
                            )
                          )}
                    </p>
                  </div>
                </div>

                {/*
                 * A row per box: the size, its price, and how many. This is the
                 * whole change - a customer takes two elevens and three sixes in
                 * one order, and each is its own line. See docs/adr/0021.
                 */}
                <ul className="mt-3 space-y-2">
                  {product.variants.map((variant) => {
                    const quantity = lines[variant.id] ?? 0;
                    const saving =
                      variant.regularPrice != null && variant.price != null
                        ? variant.regularPrice - variant.price
                        : 0;

                    return (
                      <li
                        key={variant.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border px-3 py-2"
                      >
                        <div className="min-w-0">
                          <p className="font-medium">{variant.label}</p>
                          {product.priceHidden ? (
                            <p className="text-xs text-muted-foreground">
                              {t('shop.priceOnCall')}
                            </p>
                          ) : (
                            <p className="flex flex-wrap items-center gap-x-2 text-xs">
                              <span className="tabular font-semibold">
                                {formatMoney(variant.price ?? 0)}
                              </span>
                              {saving > 0 && (
                                <>
                                  <s className="tabular text-muted-foreground">
                                    {formatMoney(variant.regularPrice ?? 0)}
                                  </s>
                                  <span className="font-semibold text-red-700">
                                    {formatMoney(saving)} {t('landing.save')}
                                  </span>
                                </>
                              )}
                            </p>
                          )}
                        </div>

                        {variant.inStock ? (
                          <div className="flex items-center gap-3">
                            <QuantityStepper
                              id={`qty-${variant.id}`}
                              value={quantity}
                              suffix={t('order.boxes')}
                              onChange={(value) =>
                                setLines((prev) => ({ ...prev, [variant.id]: value }))
                              }
                            />
                            {quantity > 0 && !product.priceHidden && (
                              <span className="tabular text-sm font-medium">
                                {formatMoney((variant.price ?? 0) * quantity)}
                              </span>
                            )}
                          </div>
                        ) : (
                          <Badge tone="danger">{t('catalog.outOfStock')}</Badge>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </Card>
            );
          })}
        </div>

        <Card className="mb-6">
          <h2 className="mb-4 font-semibold">{t('shop.deliveryAddress')}</h2>

          <Field label={t('shop.yourName')} htmlFor="name" error={errors['customer.name']} required>
            <Input
              id="name"
              value={customer.name}
              onChange={set('name')}
              autoComplete="name"
              required
            />
          </Field>

          <PhoneField
            id="phone"
            label={t('shop.yourPhone')}
            value={customer.phone}
            onChange={(phone) => setCustomer((prev) => ({ ...prev, phone }))}
            error={errors['customer.phone'] ?? errors.phone}
            required
          />

          {/*
           * All sixty-four, searchable, with the ones this shop delivers to
           * first. A customer whose district is simply missing from a dropdown
           * learns nothing; one who sees it marked undeliverable learns exactly
           * what happened. See components/ui/district-field.tsx.
           */}
          <Field
            label={t('order.district')}
            htmlFor="district"
            error={errors.district}
            hint={
              deliveryCharge > 0
                ? `${t('order.deliveryCharge')} ${formatMoney(deliveryCharge)}`
                : undefined
            }
            required
          >
            <DistrictSelect
              id="district"
              value={customer.district}
              onChange={(district) => setCustomer((prev) => ({ ...prev, district }))}
              deliverable={deliverableDistricts}
              invalid={Boolean(errors.district)}
            />
          </Field>

          <Field
            label={t('order.address')}
            htmlFor="address"
            error={errors['customer.address']}
            required
          >
            <Textarea
              id="address"
              rows={2}
              value={customer.address}
              onChange={set('address')}
              autoComplete="street-address"
              required
            />
          </Field>

          <Field label={t('order.paymentMode')} htmlFor="paymentMode">
            <Select
              id="paymentMode"
              value={paymentMode}
              onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
            >
              <option value="cod">{t('order.cod')}</option>
              <option value="prepaid">{t('order.prepaid')}</option>
            </Select>
          </Field>

          <Field label={t('app.notes')} htmlFor="note" hint={t('app.optional')} className="mb-0">
            <Textarea id="note" rows={2} value={customer.note} onChange={set('note')} />
          </Field>
        </Card>

        {selected.length > 0 && (
          <dl className="mb-4 space-y-1 rounded-lg bg-muted p-4 text-sm">
            {!anyHidden && (
              <div className="flex justify-between">
                <dt className="text-muted-foreground">{t('order.items')}</dt>
                <dd className="tabular">{formatMoney(itemsTotal)}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-muted-foreground">{t('order.deliveryCharge')}</dt>
              <dd className="tabular">{formatMoney(deliveryCharge)}</dd>
            </div>
            {!anyHidden && (
              <div className="flex justify-between border-t border-border pt-1 font-semibold">
                <dt>{t('app.total')}</dt>
                <dd className="tabular">{formatMoney(itemsTotal + deliveryCharge)}</dd>
              </div>
            )}
            {anyHidden && (
              <p className="pt-1 text-xs text-muted-foreground">{t('shop.priceOnCall')}</p>
            )}
          </dl>
        )}
      </form>

      {/*
       * The total and the button follow the viewport rather than sitting at the
       * end of a long scroll. On a phone with eight products the decision and the
       * number behind it were previously never on screen at the same time.
       */}
      <StickyBar>
        {selected.length > 0 && (
          <div className="mb-2 flex items-baseline justify-between gap-3">
            <span className="text-xs text-muted-foreground">
              {formatNumber(selected.length)} {t('shop.itemsSelected')}
            </span>
            {!anyHidden && (
              <span className="tabular text-lg font-semibold">
                {formatMoney(itemsTotal + deliveryCharge)}
              </span>
            )}
          </div>
        )}

        {/*
         * With nothing chosen, the bar is a way to the products rather than a
         * disabled button. On a landing page the form is far below the fold, and
         * a greyed-out control pinned to the screen reads as a broken page.
         */}
        {selected.length === 0 ? (
          <a
            href={`#${PRODUCTS_ID}`}
            className="tap flex h-12 w-full items-center justify-center rounded-lg bg-primary px-6 text-base font-semibold text-primary-foreground hover:brightness-110"
          >
            {t('landing.orderNow')}
          </a>
        ) : (
          <Button type="submit" form={FORM_ID} full size="lg" loading={submit.isLoading}>
            {t('shop.placeOrder')}
          </Button>
        )}
      </StickyBar>
    </>
  );
}
