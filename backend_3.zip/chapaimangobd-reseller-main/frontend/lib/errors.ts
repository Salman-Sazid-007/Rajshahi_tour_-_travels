/**
 * Every error a user can see, in Bengali.
 *
 * The API speaks English and returns a stable `code` with each failure. The code
 * is the contract; the wording lives here. That way a server message never leaks
 * to a shopkeeper in a language they cannot read, and transport failures, which
 * the server can never report because it was never reached, get real wording too.
 *
 * A code missing from this table falls back to the server text, so a new API error
 * degrades to English rather than to nothing.
 */

import { formatMoney } from './format';

export type ErrorCopy = {
  /** What the user reads. Plain language, says what to do next where possible. */
  message: string;
  /** Shown only in development, to say what actually broke. */
  hint?: string;
};

/* ------------------------------------------------------- transport failures */

/** The request never reached the API, so there is no server code to key off. */
export const TRANSPORT = {
  OFFLINE: {
    message: 'ইন্টারনেট সংযোগ নেই। সংযোগ ঠিক করে আবার চেষ্টা করুন।',
  },
  SERVER_UNREACHABLE: {
    message: 'সার্ভারের সাথে সংযোগ করা যাচ্ছে না। একটু পরে আবার চেষ্টা করুন।',
    hint: 'The API server did not respond. Is the backend running on port 4000?',
  },
  SERVER_DOWN: {
    message: 'সার্ভার এখন কাজ করছে না। একটু পরে আবার চেষ্টা করুন।',
    hint: 'The API returned a non-JSON error page. The backend is probably not running.',
  },
  TIMEOUT: {
    message: 'সার্ভার সাড়া দিতে অনেক সময় নিচ্ছে। আবার চেষ্টা করুন।',
  },
  BAD_RESPONSE: {
    message: 'সার্ভার থেকে ভুল ধরনের উত্তর এসেছে। আবার চেষ্টা করুন।',
    hint: 'Response body was not valid JSON.',
  },
} as const satisfies Record<string, ErrorCopy>;

/* ------------------------------------------------------------- API failures */

const COPY: Record<string, ErrorCopy> = {
  /* auth and access */
  UNAUTHENTICATED: { message: 'আপনি লগইন করা নেই। আবার লগইন করুন।' },
  FORBIDDEN: { message: 'এই কাজটি করার অনুমতি আপনার নেই।' },
  PHONE_TAKEN: { message: 'এই মোবাইল নম্বর দিয়ে আগেই অ্যাকাউন্ট খোলা হয়েছে। লগইন করুন।' },
  ACCOUNT_LOCKED: {
    message: 'অনেকবার ভুল পাসওয়ার্ড দেওয়া হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন, অথবা পাসওয়ার্ড ভুলে গেলে নতুন করে সেট করুন।',
  },
  SESSION_REFRESHING: { message: 'লগইন নবায়ন হচ্ছে। আবার চেষ্টা করুন।' },
  WRONG_PASSWORD: { message: 'পাসওয়ার্ড সঠিক নয়।' },
  SAME_PASSWORD: { message: 'নতুন পাসওয়ার্ড বর্তমানটির চেয়ে আলাদা হতে হবে।' },
  SAME_PHONE: { message: 'এটি আপনার বর্তমান নম্বরই।' },
  /*
   * A temporary password from the owner reaches nothing but the account page.
   * The shell sends the person there as soon as the session says so.
   */
  PASSWORD_CHANGE_REQUIRED: { message: 'আগে নিজের একটি নতুন পাসওয়ার্ড দিন, তারপর বাকি কাজ করা যাবে।' },
  /* A deactivated reseller reads everything and may ask for a withdrawal. See docs/adr/0011. */
  RESELLER_INACTIVE: {
    message: 'আপনার অ্যাকাউন্ট নিষ্ক্রিয় করা হয়েছে। আপনি শুধু হিসাব দেখতে ও টাকা তোলার অনুরোধ করতে পারবেন।',
  },

  /* one-time codes */
  OTP_INVALID: { message: 'কোডটি সঠিক নয়। SMS-এ আসা ৬ সংখ্যার কোডটি আবার দেখে লিখুন।' },
  OTP_EXPIRED: { message: 'কোডটির মেয়াদ শেষ বা বাতিল হয়েছে। নতুন কোড চান।' },
  /* `{seconds}` is filled from the server's `retryAfter`. */
  OTP_COOLDOWN: { message: 'একটু আগেই কোড পাঠানো হয়েছে। {seconds} সেকেন্ড পর আবার চাইতে পারবেন।' },
  OTP_SEND_LIMIT: { message: 'এই নম্বরে এক ঘণ্টায় ৩টির বেশি কোড পাঠানো যায় না। পরে চেষ্টা করুন।' },
  SMS_UNAVAILABLE: {
    message: 'এই মুহূর্তে SMS পাঠানো যাচ্ছে না। একটু পরে চেষ্টা করুন।',
    hint: 'The SMS gateway is not configured or rejected the message.',
  },
  INVALID_PHONE: { message: 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন, যেমন ০১৭১২৩৪৫৬৭৮।' },
  /* Every limiter in the API answers 429 with this code, whatever its message. */
  RATE_LIMITED: { message: 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন।' },

  /* shop identity */
  INVALID_SLUG: { message: 'দোকানের ঠিকানায় শুধু ছোট হাতের ইংরেজি অক্ষর, সংখ্যা আর হাইফেন দিন।' },
  RESERVED_SLUG: { message: 'এই ঠিকানাটি সংরক্ষিত। অন্য একটি ঠিকানা বেছে নিন।' },
  SHOP_NOT_ACCEPTING: { message: 'এই দোকান এখন অর্ডার নিচ্ছে না। পরে আবার চেষ্টা করুন।' },
  SLUG_TAKEN: { message: 'এই ঠিকানাটি আগেই কেউ নিয়ে নিয়েছে। অন্যটি চেষ্টা করুন।' },

  /* pricing */
  BELOW_COST: { message: 'আপনার বিক্রয় মূল্য মালিকের দামের চেয়ে কম হতে পারবে না।' },
  ABOVE_MAX: { message: 'আপনার বিক্রয় মূল্য সর্বোচ্চ অনুমোদিত দামের চেয়ে বেশি হতে পারবে না।' },
  REGULAR_PRICE_TOO_LOW: { message: 'নিয়মিত দাম আপনার বিক্রয়মূল্যের চেয়ে বেশি হতে হবে।' },

  /* landing page */
  TOO_MANY_IMAGES: { message: 'ল্যান্ডিং পেজে সর্বোচ্চ ৬টি ছবি রাখা যায়। আগে একটি মুছুন।' },
  TOO_MANY_REVIEWS: { message: 'ল্যান্ডিং পেজে সর্বোচ্চ ১২টি রিভিউ রাখা যায়। আগে একটি মুছুন।' },
  BAD_MAX: { message: 'সর্বোচ্চ দাম মূল দামের চেয়ে কম হতে পারবে না।' },

  /* quantity and catalog */
  BELOW_MINIMUM: { message: 'সর্বনিম্ন অর্ডারের পরিমাণের চেয়ে কম দেওয়া যাবে না।' },
  INVALID_STEP: { message: 'এই পণ্যের অনুমোদিত ধাপ অনুযায়ী পরিমাণ দিন।' },
  INVALID_QUANTITY: { message: 'পরিমাণ সঠিকভাবে লিখুন।' },
  UNAVAILABLE: { message: 'পণ্যটি এখন পাওয়া যাচ্ছে না।' },
  NOT_LISTED: { message: 'পণ্যটি এই দোকানে বিক্রির জন্য নেই।' },
  OUT_OF_STOCK: { message: 'পর্যাপ্ত স্টক নেই।' },
  EMPTY_ORDER: { message: 'অন্তত একটি পণ্য যোগ করুন।' },
  DUPLICATE_LINE: { message: 'একই পণ্য একাধিকবার যোগ করা হয়েছে।' },

  /* delivery */
  NO_ZONE: { message: 'এই জেলায় এখনো ডেলিভারি দেওয়া হয় না। অন্য জেলা বাছাই করুন।' },
  DISTRICT_TAKEN: { message: 'এই জেলা আগেই অন্য একটি এলাকায় যোগ করা আছে।' },
  COURIER_REQUIRED: { message: 'কুরিয়ারের নাম লিখুন।' },

  /* money */
  CREDIT_LIMIT_EXCEEDED: {
    message: 'আপনার ক্রেডিট সীমা শেষ। অর্ডার নিশ্চিত করতে আগে টাকা জমা দিন।',
  },
  /*
   * 400 when a reseller asks for more than their balance, 409 when the owner
   * approves a withdrawal the balance no longer covers. Worded for both readers;
   * the owner's finance page adds what happens to the request. See docs/adr/0009.
   */
  INSUFFICIENT_BALANCE: { message: 'ব্যালেন্সে এই পরিমাণ টাকা নেই। টাকা উত্তোলন কখনো ব্যালেন্সের বেশি হতে পারে না।' },
  INVALID_AMOUNT: { message: 'সঠিক টাকার পরিমাণ লিখুন।' },
  ZERO_AMOUNT: { message: 'টাকার পরিমাণ শূন্যের বেশি হতে হবে।' },
  WITHDRAWAL_PENDING: { message: 'আপনার একটি উত্তোলনের অনুরোধ এখনো অপেক্ষায় আছে।' },
  LEDGER_DUPLICATE: { message: 'এই হিসাবটি আগেই যোগ করা হয়েছে। পাতা রিফ্রেশ করুন।' },

  /* orders */
  ALREADY_HANDLED: { message: 'এই অর্ডারটি এর মধ্যেই পরিবর্তন করা হয়েছে। পাতা রিফ্রেশ করুন।' },
  INVALID_TRANSITION: {
    message: 'অর্ডারের বর্তমান অবস্থা থেকে এই কাজটি করা যাবে না। পাতা রিফ্রেশ করে অবস্থা দেখে নিন।',
  },
  DELIVERY_CHARGE_LOCKED: {
    message: 'অর্ডারটি পাঠানো হয়ে গেছে, তাই ডেলিভারি চার্জ আর বদলানো যাবে না।',
  },
  CUSTOMER_LOCKED: {
    message: 'অর্ডারটি পাঠানো হয়ে গেছে, তাই ক্রেতার তথ্য আর বদলানো যাবে না।',
  },
  UNKNOWN_TRANSITION: { message: 'অর্ডারের এই কাজটি চেনা যায়নি।' },
  ORDER_CODE: { message: 'অর্ডার নম্বর তৈরি করা যায়নি। আবার চেষ্টা করুন।' },

  /* kyc and uploads */
  KYC_ALREADY_PENDING: {
    message: 'আপনার আগের কাগজপত্র এখনো যাচাই হচ্ছে। সিদ্ধান্ত না আসা পর্যন্ত নতুন করে জমা দেওয়া যাবে না।',
  },
  ALREADY_APPROVED: { message: 'এটি আগেই অনুমোদন করা হয়েছে।' },
  // The owner has not asked this reseller to verify, so there is nothing to upload.
  KYC_NOT_REQUIRED: { message: 'আপনার অ্যাকাউন্টের জন্য এখন কোনো কাগজপত্র চাওয়া হয়নি।' },
  NO_DOCUMENTS: { message: 'অন্তত একটি কাগজ আপলোড করুন।' },
  BAD_DOC_TYPE: { message: 'কাগজের ধরনটি সঠিক নয়।' },
  BAD_FILE_TYPE: { message: 'শুধু ছবি বা পিডিএফ ফাইল দিন।' },
  FILE_TOO_LARGE: { message: 'ফাইলটি অনেক বড়। ছোট ফাইল দিন।' },
  UPLOAD_FAILED: { message: 'ফাইল আপলোড করা যায়নি। আবার চেষ্টা করুন।' },
  NOT_CONFIGURED: {
    message: 'এই সুবিধাটি এখনো চালু করা হয়নি।',
    hint: 'A required integration (ImgBB, R2, SMS or Telegram) has no credentials.',
  },

  /* PLAN-4: corrections, reversals and the owner's new controls */
  STOCK_BELOW_ZERO: { message: 'এতগুলো বাদ দিলে স্টক শূন্যের নিচে চলে যাবে। সংখ্যাটি দেখে নিন।' },
  STOCK_NOT_TRACKED: { message: 'এই পণ্যের স্টক হিসাব রাখা হয় না। আগে "স্টক হিসাব রাখুন" চালু করুন।' },
  ZONE_IN_USE: {
    message: 'এই এলাকায় অর্ডার আছে, তাই মোছা যাবে না। বন্ধ করে রাখুন, নতুন অর্ডার আর আসবে না।',
  },
  COURIER_LOCKED: { message: 'কুরিয়ারের তথ্য শুধু পাঠানো অর্ডারে বদলানো যায়।' },
  COMPLAINT_OPEN: { message: 'অভিযোগটি আগে থেকেই খোলা আছে।' },
  NOT_FAILED: { message: 'এই বার্তাটি আর আটকে নেই। তালিকা নতুন করে দেখুন।' },
  SMS_NOT_RESENDABLE: { message: 'কোড বা পরীক্ষার SMS আবার পাঠানো যায় না। দরকার হলে নতুন করে পাঠান।' },
  ENTRY_NOT_REVERSIBLE: { message: 'এই ধরনের হিসাব বাতিল করা যায় না। কেনা বা খরচ থেকে বাতিল করুন।' },
  ALREADY_REVERSED: { message: 'এই হিসাবটি আগেই বাতিল করা হয়েছে।' },
  ALREADY_PAID: { message: 'এই খরচটি আগেই পরিশোধ করা হয়েছে।' },
  EXPENSE_VOIDED: { message: 'বাতিল করা খরচ পরিশোধ করা যায় না।' },
  NONCE_REUSED: {
    message: 'আগের চেষ্টাটি অন্য অঙ্কে জমা হয়ে গেছে। হিসাব দেখে নিন, তারপর আবার চেষ্টা করুন।',
  },
  DUPLICATE_VARIANT: { message: 'একই মাপের দুটি বক্স রাখা যায় না। মাপ বদলান বা একটি সরান।' },
  TOO_MANY_VARIANTS: { message: 'একটি পণ্যে ৮টির বেশি বক্স রাখা যায় না।' },

  /* malformed requests, which a person should never cause */
  BAD_JSON: {
    message: 'পাঠানো তথ্য পড়া যায়নি। পাতা রিফ্রেশ করে আবার চেষ্টা করুন।',
    hint: 'The request body was not valid JSON.',
  },
  PAYLOAD_TOO_LARGE: { message: 'পাঠানো তথ্য অনেক বড়। কম তথ্য বা ছোট ফাইল দিয়ে আবার চেষ্টা করুন।' },
  UNSUPPORTED_ENCODING: { message: 'পাঠানো তথ্যের ধরন সার্ভার চেনে না। আবার চেষ্টা করুন।' },
  UNSUPPORTED_CHARSET: { message: 'পাঠানো তথ্যের ধরন সার্ভার চেনে না। আবার চেষ্টা করুন।' },
  REQUEST_ABORTED: { message: 'অনুরোধটি মাঝপথে থেমে গেছে। আবার চেষ্টা করুন।' },
  BAD_CURSOR: { message: 'তালিকাটি পুরনো হয়ে গেছে। পাতা রিফ্রেশ করে আবার দেখুন।' },
  BAD_REQUEST: { message: 'অনুরোধটি সঠিক নয়। পাতা রিফ্রেশ করে আবার চেষ্টা করুন।' },

  /* generic */
  VALIDATION_FAILED: { message: 'কিছু তথ্য সঠিক নয়। নিচে দেখুন।' },
  /*
   * The cost side (PLAN-3). Without these the banner falls back to the server's
   * English string, which in an all-Bengali app reads as a crash.
   */
  SUPPLY_SHORT: { message: 'স্টকে এত নেই। আগে গণনা করে হিসাব ঠিক করুন।' },
  SUPPLY_ARCHIVED: { message: 'এই আইটেমটি আর্কাইভ করা। আগে ফিরিয়ে আনুন।' },
  PAYEE_ARCHIVED: { message: 'এই পাওনাদার আর্কাইভ করা। আগে ফিরিয়ে আনুন।' },
  CATEGORY_ARCHIVED: { message: 'এই খাতটি আর্কাইভ করা। আগে ফিরিয়ে আনুন।' },
  DUPLICATE_SUPPLY: { message: 'একই আইটেম দুই লাইনে দেওয়া হয়েছে। একটি সরিয়ে দিন।' },
  DUPLICATE_PACKAGING_ROW: { message: 'এই আইটেমটি এই বক্সের তালিকায় আগেই আছে।' },
  TOO_MANY_PACKAGING_ROWS: { message: 'একটি বক্সে সর্বোচ্চ ছয়টি আইটেম দেওয়া যায়।' },
  NO_LINES: { message: 'অন্তত একটি আইটেম যোগ করুন।' },
  // A purchase is cancelled and re-entered, never edited. docs/adr/0024.
  ALREADY_CANCELLED: { message: 'এই ক্রয়টি আগেই বাতিল করা হয়েছে। পাতাটি রিফ্রেশ করুন।' },
  ALREADY_VOIDED: { message: 'এই খরচটি আগেই বাতিল করা হয়েছে। পাতাটি রিফ্রেশ করুন।' },
  /*
   * A period cost like লেবার belongs to a day, not to one parcel. Refused rather
   * than reinterpreted, because a mis-scoped cost is summed into a margin and
   * believed. docs/adr/0027.
   */
  WRONG_EXPENSE_SCOPE: { message: 'এই খাতটি অন্য হিসাবের জন্য। খাতটি বদলান, বা অর্ডারটি সরিয়ে দিন।' },
  PAYEE_REQUIRED: { message: 'বাকি রাখলে কাকে দিতে হবে সেটা বলতে হবে।' },
  PAYEE_LEDGER_DUPLICATE: { message: 'এই লেনদেনটি আগেই লেখা হয়েছে। পাতাটি রিফ্রেশ করুন।' },
  SUPPLY_MOVEMENT_DUPLICATE: { message: 'এই নড়াচড়াটি আগেই লেখা হয়েছে। পাতাটি রিফ্রেশ করুন।' },

  DUPLICATE: { message: 'এই তথ্যটি আগেই ব্যবহার করা হয়েছে।' },
  NOT_FOUND: { message: 'যা খুঁজছেন তা পাওয়া যায়নি।' },
  INVALID_ID: { message: 'ঠিকানাটি সঠিক নয়।' },
  INTERNAL: { message: 'সার্ভারে সমস্যা হয়েছে। আবার চেষ্টা করুন।' },
  UNKNOWN: { message: 'অজানা সমস্যা হয়েছে। আবার চেষ্টা করুন।' },
};

/** Bengali copy for a server error code, or undefined to fall back to the server. */
export const copyFor = (code: string): ErrorCopy | undefined => COPY[code];

/**
 * Field-level messages come from zod and from validators, in English. The common
 * ones are translated by their exact text so form fields read correctly too.
 */
const FIELD_COPY: Record<string, string> = {
  Required: 'এই ঘরটি পূরণ করুন',
  'Already registered': 'এই নম্বরটি আগেই ব্যবহৃত',
  'Already in use': 'এটি আগেই ব্যবহৃত',
  'Name is required': 'নাম লিখুন',
  'Phone number is required': 'মোবাইল নম্বর লিখুন',
  'Use at least 6 characters': 'অন্তত ৬টি অক্ষর দিন',
  'Must be above your price': 'আপনার বিক্রয়মূল্যের চেয়ে বেশি দিন',
  'Write the review or add a screenshot': 'রিভিউ লিখুন বা স্ক্রিনশট দিন',
  'Enter a full link': 'https:// সহ পুরো লিংক দিন',
  'Enter a valid Bangladeshi mobile number': 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন',
  'Enter the 6 digit code': '৬ সংখ্যার কোডটি লিখুন',
  'Wrong code': 'কোডটি সঠিক নয়',
  'Code expired': 'কোডের মেয়াদ শেষ, নতুন কোড চান',
  'Wrong password': 'পাসওয়ার্ড সঠিক নয়',
  'Same as current password': 'বর্তমান পাসওয়ার্ডের চেয়ে আলাদা দিন',
  'Same as current': 'এটি আপনার বর্তমান নম্বর',
  'We do not deliver to that district yet': 'এই জেলায় এখনো ডেলিভারি দেওয়া হয় না',
};

/** Field messages that carry a figure, so they cannot be matched by exact text. */
const FIELD_PATTERNS: [RegExp, (match: RegExpMatchArray) => string][] = [
  // A withdrawal above the balance: "At most 120.5 taka".
  [/^At most (-?\d+(?:\.\d+)?) taka$/, (m) => `সর্বোচ্চ ${formatMoney(Number(m[1]))} তোলা যাবে`],
];

export const translateField = (text: string): string => {
  if (FIELD_COPY[text]) return FIELD_COPY[text];
  for (const [pattern, build] of FIELD_PATTERNS) {
    const match = text.match(pattern);
    if (match) return build(match);
  }
  return text;
};
