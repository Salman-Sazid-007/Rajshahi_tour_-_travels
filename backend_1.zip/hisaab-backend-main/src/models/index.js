// Export all models for easy importing
module.exports = {
  Admin: require('./Admin.model'),
  Shop: require('./Shop.model'),
  Branch: require('./Branch.model'),
  User: require('./User.model'),
  // Forgot-password attempts, keyed on the phone rather than on a user (one
  // number can hold accounts in several shops). Registered here or
  // `sync-indexes` never ships its unique phone key or the `purgeAt` TTL to
  // production, where autoIndex is off — and without the TTL the collection
  // grows forever while abandoned reset codes stay queryable.
  PasswordReset: require('./PasswordReset.model'),
  Role: require('./Role.model'),
  Customer: require('./Customer.model'),
  CustomerBalance: require('./CustomerBalance.model'),
  DueAdjustment: require('./DueAdjustment.model'),
  Supplier: require('./Supplier.model'),
  SupplierBalance: require('./SupplierBalance.model'),
  // Payable carried in from the shop's paper খাতা. A separate collection from
  // `DueAdjustment` on purpose — the customer due-aging report aggregates that
  // one with no customer predicate, so supplier debt in it would read as
  // receivables. Registered here or `sync-indexes` never ships the খতিয়ান
  // index to production, where autoIndex is off.
  SupplierDueAdjustment: require('./SupplierDueAdjustment.model'),
  Category: require('./Category.model'),
  Product: require('./Product.model'),
  Sale: require('./Sale.model'),
  Payment: require('./Payment.model'),
  // Platform billing — what shops pay HisaabBD. Separate from `Payment`, which
  // is what a shop's customers pay the shop.
  PlatformPayment: require('./PlatformPayment.model'),
  // One attempt to pay us through the gateway — the intent that sits between
  // "the owner tapped a package" and "the money arrived". Registered here or
  // `sync-indexes` never ships them to production, where autoIndex is off, and
  // the two that matter most are lost: the unique `invoiceNumber` that stops a
  // mint collision becoming a gateway `1008`, and `{status, createdAt}`, which
  // is the reconciliation sweep's only query — without it the sweep is a
  // collection scan every five minutes, forever.
  PlatformOrder: require('./PlatformOrder.model'),
  SubscriptionEvent: require('./SubscriptionEvent.model'),
  PlatformSetting: require('./PlatformSetting.model'),
  // Where the shop's own money sits — the cash box, each bank account, each
  // bKash/Nagad number — each carrying its own balance. Registered here or
  // `sync-indexes` never ships the unique {shop, branch, name} key to
  // production, where autoIndex is off, and two accounts with the same name can
  // then exist in one branch with nothing to say which one a payment meant.
  PaymentAccount: require('./PaymentAccount.model'),
  // Money moving between two of the above — banking the takings, cashing out
  // bKash. Registered here or `sync-indexes` never ships the per-shop unique
  // `transferNo` key to production, where autoIndex is off, and two transfers
  // can then share a number with nothing to tell them apart.
  AccountTransfer: require('./AccountTransfer.model'),
  // The atomic sequence behind that number. Registered for the same reason —
  // its unique `{shop}` key is what stops two concurrent transfers being handed
  // the same sequence, which is the race `ReturnCounter` was created to end.
  AccountTransferCounter: require('./AccountTransferCounter.model'),
  // Owner deposits and withdrawals, loans, corrections — money that moves a
  // balance and never touches profit. Registered here or `sync-indexes` never
  // ships its `{shop, account, date}` index and the money-position screen falls
  // back to a collection scan on every load.
  AccountEntry: require('./AccountEntry.model'),
  // "The statement says X, the app says Y." Same reason.
  AccountReconciliation: require('./AccountReconciliation.model'),
  // কেনা ফেরত — goods sent back to a supplier. Registered here or
  // `sync-indexes` never sees the collection at all, and production (autoIndex
  // off) gets NONE of its indexes: the unique `{shop, returnNo}` that stops two
  // returns sharing a number, the `{shop, purchase}` the max-returnable map is
  // built from, and the `{shop, branch, refundStatus, createdAt}` behind the
  // "টাকা ফেরত পাওয়া বাকি" banner. Every one of those would fall back to a
  // collection scan or, in the unique case, to no guard at all.
  PurchaseReturn: require('./PurchaseReturn.model'),
  StockTransaction: require('./StockTransaction.model'),
  // কাঁচামাল (features.restaurant) — CLAUDE.md §18. Registered so
  // `sync-indexes` ships their indexes; production runs autoIndex off.
  Ingredient: require('./Ingredient.model'),
  IngredientMovement: require('./IngredientMovement.model'),
  AuditLog: require('./AuditLog.model'),
  SMSLog: require('./SMSLog.model'),
  SMSQuota: require('./SMSQuota.model'),
  SmsEarning: require('./SmsEarning.model'),
  ShopCategory: require('./ShopCategory.model'),
  GeminiKey: require('./GeminiKey.model'),
  // Per-BRANCH daily AI message counter. Registered here or `sync-indexes`
  // never ships the unique `{shop, branch}` key to production, where autoIndex
  // is off — and without it the three-step `reserve` can race two counters into
  // existence for one branch and silently double its allowance.
  ShopAiUsage: require('./ShopAiUsage.model'),
  // The R2 storage pool. One document per Cloudflare bucket; see
  // services/storage.service.js for how one is chosen per upload.
  R2Account: require('./R2Account.model'),
  // One uploaded image. Carries the dedupe hash, the refCount that makes
  // reclamation possible, and the account+key that make URLs rebuildable.
  ShopMedia: require('./ShopMedia.model'),
  // The platform's OWN media library — admin-only, never shop-facing, charged to
  // no shop's quota. Backs landing page authoring; see MEDIA_GALLERY_PLAN.md
  // I-20. Registered here or `sync-indexes` never ships the unique platform-wide
  // dedupe index or the `refs.page` lookup the I-18 reconciler runs.
  MediaFolder: require('./MediaFolder.model'),
  PlatformMedia: require('./PlatformMedia.model'),
  // Seasonal landing pages. Sealed off from the ledger by design: a LandingOrder
  // never becomes a Sale and never creates a Customer (LANDING_PAGE_PLAN.md
  // I-17). Registered here or `sync-indexes` never ships the unique slug, the
  // per-shop order-number index or the counter's TTL to production.
  LandingPage: require('./LandingPage.model'),
  LandingOrder: require('./LandingOrder.model'),
  LandingOrderCounter: require('./LandingOrderCounter.model'),
  // The online storefront. `StorefrontTemplate` is the platform-owned catalogue
  // of designs; `Storefront` is one shop's site, granted a subset of them.
  // Neither is read by any pre-existing query — see ECOMMERCE_PLAN.md I-8.
  StorefrontTemplate: require('./StorefrontTemplate.model'),
  Storefront: require('./Storefront.model'),
  // Online orders — the ledger-adjacent worklist (I-9: an Order is not a Sale).
  // Registered here or `sync-indexes` never ships the worklist index and the
  // unique idempotency backstop to production (autoIndex is off there).
  Order: require('./Order.model'),
  OrderCounter: require('./OrderCounter.model'),
  // The two sequence counters, registered for the same reason OrderCounter is:
  // each carries a unique key index and a 30-day TTL, and `sync-indexes` only
  // ships indexes for models listed here. Without registration the unique index
  // that makes the counter safe under concurrency never reaches production,
  // where autoIndex is off — which would leave the race these models exist to
  // remove still open, silently.
  InvoiceCounter: require('./InvoiceCounter.model'),
  ReturnCounter: require('./ReturnCounter.model'),
  TelegramLink: require('./TelegramLink.model'),
  TelegramLinkToken: require('./TelegramLinkToken.model'),
  NotificationLog: require('./NotificationLog.model'),

  // The operator's own alert channel and the step-up challenge behind admin
  // password changes. Registered here for the reason the comment above gives:
  // `sync-indexes` only ships indexes for models listed in this file, and both
  // of these carry a unique index plus a TTL that production cannot do without
  // — the challenge's `{admin, purpose}` unique is what stops a double-tapped
  // "send code" from minting two live codes.
  AdminTelegramLink: require('./AdminTelegramLink.model'),
  AdminTelegramLinkToken: require('./AdminTelegramLinkToken.model'),
  AdminSecurityChallenge: require('./AdminSecurityChallenge.model')
};


