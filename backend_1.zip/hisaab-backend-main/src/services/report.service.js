const Sale = require('../models/Sale.model');
const Product = require('../models/Product.model');
const Customer = require('../models/Customer.model');
const CustomerBalance = require('../models/CustomerBalance.model');
const Payment = require('../models/Payment.model');
const Expense = require('../models/Expense.model');
const SalesReturn = require('../models/SalesReturn.model');
const Purchase = require('../models/Purchase.model');
const AccountTransfer = require('../models/AccountTransfer.model');
const { LIVE_TRANSFER } = AccountTransfer;
// The stock ledger. Read by the P&L for one thing only: the ক্ষতি term, which
// exists in no sales figure — see the shrinkage aggregation in getProfitLoss.
const StockTransaction = require('../models/StockTransaction.model');
const CashRegister = require('../models/CashRegister.model');
const Branch = require('../models/Branch.model');
const User = require('../models/User.model');
const Role = require('../models/Role.model');
const mongoose = require('mongoose');
const cacheService = require('./cache.service');
const { KEYS, getTTL } = require('../config/cacheKeys');
const { isBranchCustomerScope } = require('../utils/branchScope.util');
const { quantizeMoney } = require('../utils/quantity.util');
const { MAX_DECIMALS } = require('../config/units');
// Safe direction: customer.service depends on models only, never on reports.
const customerService = require('./customer.service');

// Scoping and rounding primitives are shared with staffReport.service.js — see
// utils/reportScope.util.js for why they no longer live here.
const {
  baseMatch: sharedBaseMatch,
  buildDateMatch: sharedBuildDateMatch,
  netSaleAmountExpr,
  roundReportQty,
} = require('../utils/reportScope.util');
const staffReportService = require('./staffReport.service');

/**
 * Aggregation stage that applies the same snap server-side, for pipelines whose
 * `$group` output is sorted and returned without passing through JS. Must come
 * AFTER the `$group` — `$round` cannot wrap a `$sum` accumulator in place.
 */
const roundQtyStage = { $set: { totalQuantity: { $round: ['$totalQuantity', MAX_DECIMALS] } } };

/* ───────────────────────────────────────────────────────────────────────────
 * DAY-STABLE ACCOUNTING
 * ───────────────────────────────────────────────────────────────────────────
 *
 * A day-book must be final once the day closes. Reopening 8 August in October
 * has to show what 8 August showed in August, or it is not a book — it is a
 * live query wearing a date, and nobody can reconcile against it.
 *
 * The default reporting shape does not have that property, for two reasons,
 * and both of them are in the SALE document rather than in any report:
 *
 *   1. A return REWRITES the original sale. `returnedAmount` goes up and
 *      `profit` comes down, in place, on the invoice from August. Every report
 *      built on `netSaleAmountExpr` (total − returnedAmount) or on `$profit`
 *      therefore restates August the moment a customer walks in during October.
 *
 *   2. A return that empties an invoice CANCELS it (`salesReturn.service`,
 *      "Fully returned AND nothing left owing"). The standard
 *      `status: { $ne: 'cancelled' }` filter then drops that sale from its own
 *      day entirely — August loses a whole invoice and an order off its count.
 *
 * Together they double-count every return: once as a silent reduction on the
 * day of the SALE, and again as a returns line on the day of the RETURN.
 *
 * The three expressions below are the fix. They reconstruct what the invoice
 * said on the day it was written, from fields the return path maintains as
 * accumulators, and the returns are then booked — once — on the day they
 * actually happened.
 *
 * ── This is not a contradiction of `netSaleAmountExpr` ──────────────────────
 *
 * That expression answers "what is this invoice worth NOW", which is the right
 * question for an invoice list, a customer statement or a staff member's
 * credited sales, and it stays the definition there. These answer "what
 * happened on this DAY", which is a different question with a different and
 * equally correct answer. A day-book and a ledger of open invoices are allowed
 * to differ; what they must not do is each silently answer half of both.
 */

/**
 * A sale as invoiced, including one later emptied by a return.
 *
 * `returnedAmount > 0` is what separates "cancelled BY a return" from a genuine
 * void: a mistaken sale that is voided outright never had anything returned
 * against it. A voided sale stays excluded — it did not happen — while a sale
 * that was real on the day and came back later stays counted on its own day,
 * with the return booked on the day it arrived.
 */
function invoicedOnDayMatch() {
  return {
    $or: [
      { status: { $ne: 'cancelled' } },
      { status: 'cancelled', returnedAmount: { $gt: 0 } },
    ],
  };
}

/**
 * Profit as invoiced, before any return took a bite out of it.
 *
 * `Sale.profit` is stored NET of returns and `Sale.returnedProfit` accumulates
 * exactly what was taken off, so their sum is invariant: the return path writes
 * `profit -= r` and `returnedProfit += r` in the same update. Reconstructing it
 * this way needs no new field and no backfill — a sale that has never been
 * returned against carries `returnedProfit: 0` and the sum is just `profit`.
 */
function grossProfitExpr() {
  return { $add: ['$profit', { $ifNull: ['$returnedProfit', 0] }] };
}

/**
 * The bill as written. `Sale.total` is never rewritten by a return — only
 * `returnedAmount` beside it is — so this is already day-stable and the
 * expression exists to be named rather than to compute anything.
 */
function grossSaleAmountExpr() {
  return '$total';
}

// Products are per-branch documents, so a report's product scope is just the
// shop plus the optional branch — no join to a separate stock collection.
function productScope(shopId, branchId, extra = {}) {
  const scope = { shop: new mongoose.Types.ObjectId(shopId), isDeleted: { $ne: true }, ...extra };
  if (branchId) scope.branch = new mongoose.Types.ObjectId(branchId);
  return scope;
}

// A product with variants holds no stock of its own — the units sit on the
// variants, and the parent `stock` rollup drifts wherever a write path skips
// the pre-save hook. Reading `$stock` for those reports every variant product
// as out of stock. Same expression as detailedReport.service.js's stock
// report, and it must stay identical — the dashboard tile and the stock report
// counting "low" from different fields is a contradiction an owner can see on
// one screen. Guarded on `hasVariants`, not `variants.length`: a
// converted-back product (flag false, stale `variants[]` summing 0) keeps its
// real stock on `stock`, and summing its abandoned variants would zero it.
const effectiveStockExpr = {
  $cond: [
    { $eq: ['$hasVariants', true] },
    { $sum: { $ifNull: ['$variants.stock', []] } },
    { $ifNull: ['$stock', 0] },
  ],
};

// Valuation counterpart: per-variant stock × per-variant price, falling back
// to the parent price where a variant has none — detailedReport.service.js's
// `variantAware` fold, kept in step for the same reason as above.
const effectiveValueExpr = (field) => ({
  $cond: [
    { $eq: ['$hasVariants', true] },
    {
      $reduce: {
        input: { $ifNull: ['$variants', []] },
        initialValue: 0,
        in: {
          $add: [
            '$$value',
            {
              $multiply: [
                { $ifNull: ['$$this.stock', 0] },
                { $ifNull: [`$$this.${field}`, { $ifNull: [`$${field}`, 0] }] },
              ],
            },
          ],
        },
      },
    },
    { $multiply: [{ $ifNull: ['$stock', 0] }, { $ifNull: [`$${field}`, 0] }] },
  ],
});

// Bangladesh is UTC+6. All dates from frontend are in Bangladesh local time.
// These used to be defined here; they moved to utils/bdTime.util.js when the
// Telegram digest job needed the same notion of "today". Two copies of this
// conversion would eventually disagree, and a digest that reports a different
// day than the dashboard is worse than no digest.
// `BD_OFFSET_MS` is imported, not redeclared: `getDateWiseSummary` builds its
// own month boundaries from the raw offset, and a local copy here would be the
// third in the codebase (sale.service.js still has one). Two constants that
// must agree and don't is how a report ends up disagreeing with the dashboard
// about which day a sale landed on.
const { BD_OFFSET_MS, BD_TZ, getBangladeshTodayStr, getBangladeshDayRange } = require('../utils/bdTime.util');
const { paidAtMatch, LIVE_PAYMENT, PAID_AT_EXPR } = require('../utils/paymentDate.util');
const { TRACKED_FILTER } = require('../utils/stockTracking.util');
const ingredientService = require('./ingredient.service');

class ReportService {
  /**
   * Build the base $match for aggregation with optional branch scoping.
   * @param {string} shopId - Shop ID
   * @param {string|null} branchId - Branch ID (null = all branches)
   * @returns {Object} Base match object
   */
  _baseMatch(shopId, branchId = null) {
    return sharedBaseMatch(shopId, branchId);
  }

  /**
   * Build date range match object for queries.
   * Ensures end of day (23:59:59.999) is used when endDate is date-only string or midnight timestamp.
   */
  _buildDateMatch(startDate, endDate) {
    return sharedBuildDateMatch(startDate, endDate);
  }

  // Get dashboard statistics
  /**
   * Count of products below their reorder point, cached for 60s.
   *
   * ── Why this needs its own cache, on top of the dashboard's ──────────────
   *
   * The predicate compares effective stock against `minStock` — two fields of
   * the SAME document. MongoDB cannot serve that from an index, no matter how
   * the shop/branch keys are arranged, so it is a COLLECTION SCAN of the
   * shop's whole catalogue every time it runs.
   *
   * Measured at 189ms for a single query against 5k products, and it is a
   * major share of the dashboard's server time (PERFORMANCE_BASELINE.md §N-1).
   *
   * The dashboard result is already cached, but that cache is version-keyed and
   * bumped by every write burst, so an active shop misses it often and pays the
   * scan again. A short independent TTL means the scan runs at most once a
   * minute per (shop, branch) regardless of how often the dashboard is rebuilt.
   * 60s staleness is fine for a reorder alert — `getTTL.lowStock` was already
   * set to exactly that and had no caller.
   *
   * The key is scoped by `branchId` because the QUERY is scoped by `branchId`
   * (via productScope). Do not reduce that to a shop-only key — see the long
   * note on the inventory-stats key in product.service.js for what happens when
   * a cache key partitions more coarsely than the data it holds.
   *
   * A permanent fix would be a denormalized indexed flag maintained on every
   * stock write; that is a larger change and is deliberately not attempted here.
   */
  async _lowStockCount(shopId, branchId = null) {
    const cacheKey = `${KEYS.LOW_STOCK(shopId)}:count:${branchId || 'all'}`;

    // `!= null` deliberately, not a truthiness check: zero is both a perfectly
    // valid count and a cache hit worth honouring. `cached || compute` here
    // would re-run the scan for every shop that is fully stocked — that is,
    // for the healthiest shops, forever.
    const cached = await cacheService.get(cacheKey);
    if (cached != null) return cached;

    const count = await Product.countDocuments(
      productScope(shopId, branchId, { isActive: true, ...TRACKED_FILTER, $expr: { $lt: [effectiveStockExpr, '$minStock'] } })
    );
    await cacheService.set(cacheKey, count, getTTL.lowStock);
    return count;
  }

  async getDashboardStats(shopId, branchId = null, isMultiBranch = false, req = null) {
    // Customers and dues are read per-branch or shop-wide depending on the
    // shop's setting (Phase 7). The two produce different numbers from the same
    // (shop, branch), so the scope has to be part of the cache key — otherwise
    // flipping the flag would serve the old figures until the version bumps.
    const scopedCustomers = isBranchCustomerScope(req);

    // Try cache first (include branchId and shop cache version in the key —
    // sale writes bump the version instead of deleting keys)
    const version = await cacheService.getShopCacheVersion(shopId);
    const scopeTag = scopedCustomers ? ':cs=branch' : '';
    const cacheKey = branchId
      ? `${KEYS.DASHBOARD_STATS(shopId)}:branch:${branchId}${scopeTag}:v${version}`
      : `${KEYS.DASHBOARD_STATS(shopId)}:v${version}`;
    const cached = await cacheService.get(cacheKey);
    if (cached) return cached;
    const { startOfDay, endOfDay } = getBangladeshDayRange(getBangladeshTodayStr());

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    // Branch breakdown is only meaningful for a shop that actually has
    // branches. It used to run whenever no branch was selected, which is always
    // true for a single-branch shop — two extra queries on the hottest endpoint
    // for every such shop, returning an empty array (FEATURE_AUDIT.md M-12).
    const wantBranchBreakdown = isMultiBranch && !branchId;

    // These eight queries are independent of each other. They used to run as
    // eight sequential `await`s, so the endpoint paid one full network round
    // trip per query — ~500ms of pure latency before any work. Running them
    // together collapses that to roughly a single round trip.
    const [
      todaySalesResult,
      // Carries the customer COUNT too, so the tile and the due beside it can no
      // longer be counted over two different populations.
      customerDueResult,
      lowStockCount,
      totalProducts,
      recentSales,
      topProducts,
      salesChart,
      salesByBranch,
      activeBranches,
    ] = await Promise.all([
      // Today's sales
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            createdAt: { $gte: startOfDay, $lte: endOfDay },
          },
        },
        {
          $group: {
            _id: null,
            totalSales: { $sum: netSaleAmountExpr() },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            totalProfit: { $sum: '$profit' },
            count: { $sum: 1 },
          },
        },
      ]),

      // Total due across customers, and how many there are. Shop-wide unless
      // this shop keeps separate books per branch, in which case only what is
      // owed to THIS branch.
      //
      // An owner in All-Branches has no branch to scope to, and the sum across
      // every branch is precisely the shop-wide rollup — so the aggregate view
      // falls through to the same query in both modes, with no special case.
      //
      // ── Both arms must ask the SAME question ────────────────────────────────
      //
      // The branch arm used to read `CustomerBalance` raw while the shop-wide
      // arm filtered `isActive: true`. Deleted customers therefore counted at
      // branch level and vanished at shop level, so the branch tiles did not add
      // up to the All-Branches tile and there was no figure on the page that
      // explained the gap. One real shop: আক্কেলপুর ৳14,980,592 + নয়াগোলা
      // ৳639,015 = ৳15,619,607 against an All-Branches ৳15,513,302 — the
      // ৳106,305 difference being five soft-deleted customers, one of whom still
      // owed ৳106,305 of it. The join below is what keeps the two arms
      // answerable to each other; `_applyDueAdjustment` now refuses to create
      // that state in the first place.
      scopedCustomers
        ? CustomerBalance.aggregate([
          {
            $match: {
              shop: new mongoose.Types.ObjectId(shopId),
              branch: new mongoose.Types.ObjectId(branchId),
            },
          },
          {
            $lookup: {
              from: 'customers',
              localField: 'customer',
              foreignField: '_id',
              // Only the flag is needed, and the branch's due list can run to
              // thousands of rows — pulling whole customer documents through the
              // join to read one boolean is the expensive way to do this.
              pipeline: [{ $project: { isActive: 1 } }],
              as: 'c',
            },
          },
          { $unwind: '$c' },
          { $match: { 'c.isActive': true } },
          { $group: { _id: null, totalDue: { $sum: '$totalDue' }, count: { $sum: 1 } } },
        ])
        : Customer.aggregate([
          { $match: { shop: new mongoose.Types.ObjectId(shopId), isActive: true } },
          { $group: { _id: null, totalDue: { $sum: '$totalDue' }, count: { $sum: 1 } } },
        ]),

      this._lowStockCount(shopId, branchId),

      Product.countDocuments(productScope(shopId, branchId, { isActive: true })),

      Sale.find({
        shop: shopId,
        ...(branchId ? { branch: branchId } : {}),
        status: { $ne: 'cancelled' },
      })
        .populate('customer', 'name phone')
        .sort({ createdAt: -1 })
        .limit(5)
        .lean(),

      // Top selling products (last 30 days)
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            createdAt: { $gte: thirtyDaysAgo },
          },
        },
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.product',
            productName: { $first: '$items.productName' },
            totalQuantity: { $sum: '$items.quantity' },
            totalRevenue: { $sum: '$items.total' },
          },
        },
        roundQtyStage,
        { $sort: { totalQuantity: -1 } },
        { $limit: 5 },
      ]),

      // Sales chart (last 7 days)
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            createdAt: { $gte: sevenDaysAgo },
          },
        },
        {
          $group: {
            // `timezone` is not optional here — see BD_TZ in bdTime.util.js.
            // Without it these buckets are UTC days while the window above is a
            // BD day, so a sale rung at 01:00 Dhaka joins yesterday's bar.
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt', timezone: BD_TZ } },
            sales: { $sum: netSaleAmountExpr() },
            orders: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // Per-branch today's figures — multi-branch shops only
      wantBranchBreakdown
        ? Sale.aggregate([
          {
            $match: {
              shop: new mongoose.Types.ObjectId(shopId),
              status: { $ne: 'cancelled' },
              createdAt: { $gte: startOfDay, $lte: endOfDay },
            },
          },
          {
            $group: {
              _id: '$branch',
              todaySales: { $sum: netSaleAmountExpr() },
              todayProfit: { $sum: '$profit' },
              todayOrders: { $sum: 1 },
            },
          },
        ])
        : [],

      wantBranchBreakdown
        ? Branch.find({ shop: shopId, isActive: true }).lean()
        : [],
    ]);

    const todaySales = todaySalesResult[0] || { totalSales: 0, totalPaid: 0, totalDue: 0, totalProfit: 0, count: 0 };
    const totalDue = customerDueResult[0]?.totalDue || 0;
    const totalCustomers = customerDueResult[0]?.count || 0;

    const branchBreakdown = activeBranches.map((branch) => {
      const stats = salesByBranch.find((x) => x._id && x._id.toString() === branch._id.toString()) || {
        todaySales: 0,
        todayProfit: 0,
        todayOrders: 0,
      };
      return {
        branchId: branch._id,
        name: branch.name,
        code: branch.code,
        address: branch.address,
        phone: branch.phone,
        isDefault: branch.isDefault,
        todaySales: stats.todaySales,
        todayProfit: stats.todayProfit,
        todayOrders: stats.todayOrders,
      };
    });

    const result = {
      todaySales: todaySales.totalSales,
      todayProfit: todaySales.totalProfit,
      todayOrders: todaySales.count,
      totalDue,
      lowStockCount,
      totalCustomers,
      totalProducts,
      recentSales,
      topProducts,
      salesChart,
      branchBreakdown,
    };

    // Cache the result
    await cacheService.set(cacheKey, result, getTTL.dashboardStats);
    return result;
  }


  // Get sales report — uses $facet to combine period breakdown, summary, and profit in a single pipeline
  async getSalesReport(shopId, options = {}, branchId = null) {
    const { startDate, endDate, groupBy = 'day' } = options;

    // Versioned cache, same contract as getDashboardStats/getProfitLoss: sale
    // writes bump the shop's version (debounced to once per 30s) and superseded
    // entries age out on TTL. `KEYS.SALES_REPORT` and `getTTL.salesReport` were
    // already defined in config/cacheKeys.js and had no caller.
    //
    // The key carries every input the pipeline is scoped by — dates, groupBy AND
    // branch. Dropping branch here would serve one branch's figures to another
    // for five minutes; see the long note on the inventory-stats key in
    // product.service.js for what that looks like in practice.
    const srVersion = await cacheService.getShopCacheVersion(shopId);
    const srCacheKey =
      `${KEYS.SALES_REPORT(shopId, startDate, endDate, groupBy)}:branch:${branchId || 'all'}:v${srVersion}`;
    const srCached = await cacheService.get(srCacheKey);
    if (srCached) return srCached;

    const matchStage = {
      ...this._baseMatch(shopId, branchId),
      status: { $ne: 'cancelled' },
    };

    const dateMatch = this._buildDateMatch(startDate, endDate);
    if (dateMatch) {
      matchStage.createdAt = dateMatch;
    }

    let dateFormat;
    switch (groupBy) {
      case 'hour':
        dateFormat = '%Y-%m-%d %H:00';
        break;
      case 'day':
        dateFormat = '%Y-%m-%d';
        break;
      case 'week':
        // `%G`, not `%Y`. `%V` is the ISO-8601 week number, whose year is the
        // ISO WEEK-year (`%G`) and not the calendar year — the two disagree at
        // 82 of the next 100 year boundaries. Pairing `%V` with `%Y` labelled
        // 31 Dec 2029 as "2029-W01", which sorts to the top of the year and
        // merges with the real January week whenever a range spans both.
        dateFormat = '%G-W%V';
        break;
      case 'month':
        dateFormat = '%Y-%m';
        break;
      default:
        dateFormat = '%Y-%m-%d';
    }

    // Single $facet pipeline: one DB scan for both period data and summary
    const facetResult = await Sale.aggregate([
      { $match: matchStage },
      {
        $facet: {
          byPeriod: [
            {
              $group: {
                _id: {
                  $dateToString: { format: dateFormat, date: '$createdAt', timezone: BD_TZ },
                },
                totalSales: { $sum: netSaleAmountExpr() },
                totalPaid: { $sum: '$paid' },
                totalDue: { $sum: '$due' },
                count: { $sum: 1 },
              },
            },
            { $sort: { _id: 1 } },
          ],
          summary: [
            {
              $group: {
                _id: null,
                totalSales: { $sum: netSaleAmountExpr() },
                totalPaid: { $sum: '$paid' },
                totalDue: { $sum: '$due' },
                totalProfit: { $sum: '$profit' },
                count: { $sum: 1 },
              },
            },
          ],
        },
      },
    ]);

    const data = facetResult[0]?.byPeriod || [];
    const summary = facetResult[0]?.summary[0] || { totalSales: 0, totalPaid: 0, totalDue: 0, totalProfit: 0, count: 0 };

    const srResult = {
      data,
      summary,
    };

    await cacheService.set(srCacheKey, srResult, getTTL.salesReport);
    return srResult;
  }

  // Get product report
  async getProductReport(shopId, options = {}, branchId = null) {
    const { startDate, endDate } = options;

    // Cached for the same reason `_lowStockCount` above is: two of the four
    // queries below compare effective stock against `minStock`, a comparison
    // between two fields of one document that MongoDB cannot serve from an
    // index at any arrangement. Each is a collection scan of the shop's
    // catalogue. The dashboard already shields its copy behind a 60s cache;
    // this method ran the same scan twice on every call with no cache at all.
    //
    // Two keys, not one: only `topSelling` depends on the date range. The
    // stock lists and the summary are point-in-time snapshots of the
    // catalogue, and caching them under a range-scoped key re-ran the
    // catalogue scans once per distinct range — the exact scans this cache
    // exists to shield — while letting two cached ranges disagree about what
    // is currently low.
    const prVersion = await cacheService.getShopCacheVersion(shopId);
    const prTopKey =
      `${KEYS.PRODUCT_REPORT(shopId, startDate, endDate)}:branch:${branchId || 'all'}:v${prVersion}:top`;
    const prSnapshotKey =
      `${KEYS.PRODUCT_REPORT(shopId, null, null)}:branch:${branchId || 'all'}:v${prVersion}:snapshot`;

    // Top selling products
    const matchStage = {
      ...this._baseMatch(shopId, branchId),
      status: { $ne: 'cancelled' },
    };

    const dateMatch = this._buildDateMatch(startDate, endDate);
    if (dateMatch) {
      matchStage.createdAt = dateMatch;
    }

    // The halves are independent and each checks its own cache, so a request
    // whose range is new still reuses the snapshot half.
    const [topSelling, snapshot] = await Promise.all([
      (async () => {
        const cached = await cacheService.get(prTopKey);
        if (cached) return cached;
        const rows = await Sale.aggregate([
          { $match: matchStage },
          { $unwind: '$items' },
          {
            $group: {
              _id: '$items.product',
              productName: { $first: '$items.productName' },
              totalQuantity: { $sum: '$items.quantity' },
              totalRevenue: { $sum: '$items.total' },
              salesCount: { $sum: 1 },
            },
          },
          roundQtyStage,
          { $sort: { totalQuantity: -1 } },
          { $limit: 20 },
        ]);
        await cacheService.set(prTopKey, rows, getTTL.productReport);
        return rows;
      })(),

      (async () => {
        const cached = await cacheService.get(prSnapshotKey);
        if (cached) return cached;
        // `$set` overwrites `stock` with the variant fold so the rows keep the
        // exact shape the old `.select('name code stock ...')` returned.
        const [lowStock, noStock, summaryResult] = await Promise.all([
          // Low stock products
          Product.aggregate([
            { $match: productScope(shopId, branchId, { isActive: true, ...TRACKED_FILTER }) },
            { $set: { stock: effectiveStockExpr } },
            { $match: { $expr: { $lt: ['$stock', '$minStock'] } } },
            { $sort: { stock: 1 } },
            { $limit: 20 },
            { $project: { name: 1, code: 1, stock: 1, minStock: 1, sellingPrice: 1 } },
          ]),

          // No stock products
          Product.aggregate([
            { $match: productScope(shopId, branchId, { isActive: true, ...TRACKED_FILTER }) },
            { $set: { stock: effectiveStockExpr } },
            { $match: { stock: { $lte: 0 } } },
            { $limit: 20 },
            { $project: { name: 1, code: 1, stock: 1, minStock: 1, sellingPrice: 1 } },
          ]),

          // Product summary
          Product.aggregate([
            { $match: productScope(shopId, branchId, { isActive: true }) },
            {
              $group: {
                _id: null,
                totalProducts: { $sum: 1 },
                totalStock: { $sum: effectiveStockExpr },
                totalValue: { $sum: effectiveValueExpr('sellingPrice') },
              },
            },
          ]),
        ]);
        const part = {
          lowStock,
          noStock,
          summary: summaryResult[0] || { totalProducts: 0, totalStock: 0, totalValue: 0 },
        };
        await cacheService.set(prSnapshotKey, part, getTTL.productReport);
        return part;
      })(),
    ]);

    return { topSelling, ...snapshot };
  }

  // Get customer report
  // Customers are shop-wide (product decision #2/#7), so this report is
  // deliberately NOT branch-scoped. It previously accepted a `branchId` and
  // silently ignored it, which read as a bug (FEATURE_AUDIT.md H-9).
  async getCustomerReport(shopId, options = {}, req = null) {
    const { startDate, endDate } = options;

    // Reverses locked decision #7 ("customer report is shop-wide"): under
    // separate books a shop-wide report would hand every branch the customer
    // list and dues the rest of this phase keeps apart.
    const scopedCustomers = isBranchCustomerScope(req);
    const branchId = scopedCustomers ? req.branchId : null;

    // New customers in date range
    const matchStage = {
      shop: new mongoose.Types.ObjectId(shopId),
      isActive: true,
    };

    const dateMatch = this._buildDateMatch(startDate, endDate);
    if (dateMatch) {
      matchStage.createdAt = dateMatch;
    }

    // The four reads below share no state, so they run together — this was
    // the one report on the shelf still paying four sequential round trips.
    //
    // Deliberately NOT cached, unlike its siblings. The shop cache version is
    // bumped by sale and product writes only; a due collection does not bump
    // it, and the middle of this report IS the due list. Caching it under the
    // same version would show an owner the debt they collected five minutes
    // ago as still outstanding. Parallelism is the whole win here.
    const [topCustomers, customersWithDue, newCustomers, summaryResult] = await Promise.all([
      // Top customers by purchase
      scopedCustomers
        ? customerService._topBranchBalances(shopId, branchId, { sortField: 'totalPurchases', limit: 20 })
        : Customer.find({
          shop: shopId,
          isActive: true,
        })
          .select('name phone totalPurchases totalPaid totalDue purchaseCount lastPurchase')
          .sort({ totalPurchases: -1 })
          .limit(20)
          .lean(),

      // Customers with due
      scopedCustomers
        ? customerService._topBranchBalances(shopId, branchId, {
          sortField: 'totalDue',
          limit: 20,
          extraMatch: { totalDue: { $gt: 0 } },
        })
        : Customer.find({
          shop: shopId,
          isActive: true,
          totalDue: { $gt: 0 },
        })
          .select('name phone totalDue lastPurchase')
          .sort({ totalDue: -1 })
          .limit(20)
          .lean(),

      // "New" means new TO THIS BRANCH under separate books — a customer who has
      // shopped elsewhere for years is still new here the first time they walk in,
      // so this keys off when the branch ledger row appeared, not the person.
      scopedCustomers
        ? CustomerBalance.aggregate([
          {
            $match: {
              shop: new mongoose.Types.ObjectId(shopId),
              branch: new mongoose.Types.ObjectId(branchId),
              ...(dateMatch ? { createdAt: dateMatch } : {}),
            },
          },
          { $sort: { createdAt: -1 } },
          { $limit: 20 },
          { $lookup: { from: 'customers', localField: 'customer', foreignField: '_id', as: 'customer' } },
          { $unwind: '$customer' },
          { $match: { 'customer.isActive': true } },
          { $project: { _id: '$customer._id', name: '$customer.name', phone: '$customer.phone', createdAt: 1 } },
        ])
        : Customer.find(matchStage)
          .select('name phone createdAt')
          .sort({ createdAt: -1 })
          .limit(20)
          .lean(),

      // Customer summary
      scopedCustomers
        ? CustomerBalance.aggregate([
          {
            $match: {
              shop: new mongoose.Types.ObjectId(shopId),
              branch: new mongoose.Types.ObjectId(branchId),
            },
          },
          {
            $group: {
              _id: null,
              totalCustomers: { $sum: 1 },
              totalDue: { $sum: '$totalDue' },
              totalPurchases: { $sum: '$totalPurchases' },
            },
          },
        ])
        : Customer.aggregate([
          {
            $match: {
              shop: new mongoose.Types.ObjectId(shopId),
              isActive: true,
            },
          },
          {
            $group: {
              _id: null,
              totalCustomers: { $sum: 1 },
              totalDue: { $sum: '$totalDue' },
              totalPurchases: { $sum: '$totalPurchases' },
            },
          },
        ]),
    ]);

    const summary = summaryResult[0] || { totalCustomers: 0, totalDue: 0, totalPurchases: 0 };

    return {
      topCustomers,
      customersWithDue,
      newCustomers,
      summary,
    };
  }

  // Get Daily Business Summary
  async getDailySummary(shopId, options = {}, branchId = null) {
    const { date } = options;
    // Use Bangladesh today if no date provided
    const dateStr = date || getBangladeshTodayStr();

    // Try cache first. Only today's summary changes as sales come in, so only
    // today's key carries the shop cache version; past dates cache on TTL alone.
    const isToday = dateStr === getBangladeshTodayStr();
    const versionSuffix = isToday ? `:v${await cacheService.getShopCacheVersion(shopId)}` : '';
    const cacheKey = (branchId
      ? `${KEYS.DAILY_SUMMARY(shopId, dateStr)}:branch:${branchId}`
      : KEYS.DAILY_SUMMARY(shopId, dateStr)) + versionSuffix;
    const cached = await cacheService.get(cacheKey);
    if (cached) return cached;

    const shopObjId = new mongoose.Types.ObjectId(shopId);

    // Parse date as Bangladesh local time (UTC+6) to get correct UTC boundaries
    const { startOfDay, endOfDay } = getBangladeshDayRange(dateStr);

    const dateMatch = { createdAt: { $gte: startOfDay, $lte: endOfDay } };
    const expenseDateMatch = { date: { $gte: startOfDay, $lte: endOfDay } };
    // Purchases are backdatable: `date` is the client-supplied business date,
    // and the purchase list and supplier statement already book on it. Keyed
    // on `createdAt`, a backdated purchase landed on the day it was typed
    // instead of the day it belongs to.
    const purchaseDateMatch = { date: { $gte: startOfDay, $lte: endOfDay } };

    // Run all aggregations in parallel
    const [
      salesAgg,
      salesByMethod,
      salesByHour,
      expenseAgg,
      expenseByCategory,
      purchaseAgg,
      dueCollections,
      returnsAgg,
      cashRegister,
      topProducts,
      lowStockProducts,
    ] = await Promise.all([
      // 1. Sales summary — gross and as-invoiced. The day's returns are a
      // book of their own (#8 below) and are subtracted once, at the bottom,
      // on the day they arrived. See DAY-STABLE ACCOUNTING at the top.
      Sale.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), ...invoicedOnDayMatch(), ...dateMatch } },
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: grossSaleAmountExpr() },
            totalProfit: { $sum: grossProfitExpr() },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            // `discountAmount`, not `discount`. The latter holds "10" on a
            // percentage invoice, so summing it reported ৳10 of discount given
            // on a ৳10,000 sale — the figure was meaningless for any shop that
            // discounts by percentage. `$ifNull` falls back for invoices written
            // before the resolved amount was stored; those are overwhelmingly
            // `fixed`, where the two fields agree by definition.
            totalDiscount: { $sum: { $ifNull: ['$discountAmount', '$discount'] } },
            // ── Per-LINE discounts, which nothing used to count ───────────────
            //
            // `discountAmount` above is the INVOICE-level discount only. From
            // the moment `features.lineDiscount` shipped, a shop could knock
            // ৳10 a kilo off individual items all month and "মোট ছাড়" would
            // report ৳0 — the exact figure an owner switches the capability on
            // to watch.
            //
            // Reported as its OWN number rather than merged into the one above.
            // "I gave ৳2,000 off whole bills" and "I gave ৳8,000 off individual
            // items" are different management problems: the first is a policy,
            // the second is usually one member of staff.
            //
            // `$reduce`, not `$sum: '$items.discount'` — the latter is a valid
            // expression on an array field but silently yields 0 for documents
            // whose `items` is missing, and `$ifNull` on each line is what
            // keeps a pre-feature sale item (no `discount` key at all) from
            // turning the whole sum into null.
            totalLineDiscount: {
              $sum: {
                $reduce: {
                  input: { $ifNull: ['$items', []] },
                  initialValue: 0,
                  in: { $add: ['$$value', { $ifNull: ['$$this.discount', 0] }] },
                },
              },
            },
            totalItems: { $sum: { $size: '$items' } },
            count: { $sum: 1 },
            /**
             * ── The day's online half ────────────────────────────────────────
             *
             * Conditional sums inside the EXISTING group rather than a second
             * aggregation: it costs no extra query, and — more importantly — it
             * cannot disagree with the totals beside it, because it is the same
             * pass over the same matched documents. The offline half is derived
             * by subtraction below for exactly that reason; two independently
             * summed halves are two things that can drift.
             *
             * Zero for every shop that sells only at the counter, which is what
             * every one of these figures said before this existed.
             */
            onlineRevenue: {
              $sum: { $cond: [{ $eq: ['$isOnline', true] }, grossSaleAmountExpr(), 0] },
            },
            onlineProfit: {
              $sum: { $cond: [{ $eq: ['$isOnline', true] }, grossProfitExpr(), 0] },
            },
            onlineDue: {
              $sum: { $cond: [{ $eq: ['$isOnline', true] }, { $ifNull: ['$due', 0] }, 0] },
            },
            onlineCount: {
              $sum: { $cond: [{ $eq: ['$isOnline', true] }, 1, 0] },
            },
          },
        },
      ]),

      // 2. Money taken at the counter, by payment method
      //
      // ── Grouped on the LEGS, not on `paymentMethod` ──────────────────────
      //
      // `Sale.paymentMethod` is not "how this invoice was paid". On a split
      // invoice `createSale` sets it to whichever leg was LARGEST (see
      // sale.service `payments.reduce(...)`), while `total` stays the whole
      // invoice. Grouping the two together therefore reported the entire
      // invoice under one method and ৳0 under the others:
      //
      //   ৳400 cash + ৳600 bKash  →  bkash ৳1000, cash ৳0
      //
      // `cashRegister.service._calculateCashFlows` spotted this trap and reads
      // the legs; this report did not, so the till and the daily summary
      // disagreed about the same day by the whole split amount.
      //
      // ── Why `total` is gone from the output ──────────────────────────────
      //
      // There is no such thing as "invoice value by method" once an invoice can
      // span methods — the ৳1000 above belongs to neither bucket. The honest
      // figure, and the one the card was always read as showing, is money
      // RECEIVED through each method. `count` is now legs, not invoices, for
      // the same reason.
      //
      // ── The fallback ─────────────────────────────────────────────────────
      //
      // `payments[]` is auto-filled for single-method sales, so it is populated
      // on everything written since split payments shipped. Sales older than
      // that have an empty array and are reconstructed from
      // `paymentMethod` + `paid` — which for a single-method sale is exactly
      // right. `paid` can include money collected against the invoice AFTER
      // checkout, so a pre-split sale later settled from বাকি reads slightly
      // high in the method split of the day it was RAISED. Only reachable for
      // sales predating the feature, and never for the current day.
      Sale.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), status: { $ne: 'cancelled' }, ...dateMatch } },
        {
          $project: {
            legs: {
              $cond: [
                { $gt: [{ $size: { $ifNull: ['$payments', []] } }, 0] },
                '$payments',
                {
                  $cond: [
                    { $gt: [{ $ifNull: ['$paid', 0] }, 0] },
                    [{ method: '$paymentMethod', amount: '$paid' }],
                    [],
                  ],
                },
              ],
            },
          },
        },
        { $unwind: '$legs' },
        {
          $group: {
            _id: '$legs.method',
            total: { $sum: { $ifNull: ['$legs.amount', 0] } },
            count: { $sum: 1 },
          },
        },
        { $sort: { total: -1 } },
      ]),

      // 3. Sales by hour (for hourly chart)
      Sale.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), status: { $ne: 'cancelled' }, ...dateMatch } },
        {
          $group: {
            _id: { $hour: '$createdAt' },
            // Gross, matching the day total this same method reports. A chart
            // whose bars do not sum to the figure printed above it is worse
            // than no chart.
            revenue: { $sum: grossSaleAmountExpr() },
            profit: { $sum: grossProfitExpr() },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // 4. Expenses summary
      Expense.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), ...expenseDateMatch } },
        {
          $group: {
            _id: null,
            totalExpenses: { $sum: '$amount' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 5. Expenses by category
      Expense.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), ...expenseDateMatch } },
        {
          $group: {
            _id: '$category',
            categoryName: { $first: '$categoryName' },
            total: { $sum: '$amount' },
            count: { $sum: 1 },
          },
        },
        { $sort: { total: -1 } },
      ]),

      // 6. Purchases summary
      Purchase.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), status: { $ne: 'cancelled' }, ...purchaseDateMatch } },
        {
          $group: {
            _id: null,
            totalPurchases: { $sum: '$totalAmount' },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 7. Due collections (payments for old dues)
      Payment.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            type: 'due_collection',
            ...LIVE_PAYMENT,
            // Effective date: a collection entered today for last Tuesday
            // belongs on last Tuesday's summary, not this one.
            ...paidAtMatch({ $gte: startOfDay, $lte: endOfDay }),
          },
        },
        {
          $group: {
            _id: '$method',
            total: { $sum: '$amount' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 8. Sales returns, on the day the goods came back.
      SalesReturn.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), ...dateMatch } },
        {
          $group: {
            _id: null,
            totalReturns: { $sum: '$totalAmount' },
            totalProfitLoss: { $sum: '$profitReduction' },
            // Only a settled CASH refund left the drawer. An `adjustment`
            // writes the customer's খাতা down and a `store_credit` moves
            // nothing until it is settled — counting either as cash out
            // reported money leaving that never did.
            cashRefund: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      { $eq: ['$refundMethod', 'cash'] },
                      { $eq: ['$refundStatus', 'settled'] },
                    ],
                  },
                  '$totalAmount',
                  0,
                ],
              },
            },
            count: { $sum: 1 },
          },
        },
      ]),

      // 9. Cash register for this date
      CashRegister.findOne({
        ...this._baseMatch(shopId, branchId),
        date: { $gte: startOfDay, $lte: endOfDay },
      }).lean(),

      // 10. Top products sold today
      Sale.aggregate([
        { $match: { ...this._baseMatch(shopId, branchId), status: { $ne: 'cancelled' }, ...dateMatch } },
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.product',
            productName: { $first: '$items.productName' },
            totalQuantity: { $sum: '$items.quantity' },
            totalRevenue: { $sum: '$items.total' },
          },
        },
        roundQtyStage,
        { $sort: { totalQuantity: -1 } },
        { $limit: 10 },
      ]),

      // 11. Low stock products — `$set` overwrites `stock` with the variant
      // fold so the rows keep the shape the old `.select(...)` returned.
      Product.aggregate([
        { $match: productScope(shopId, branchId, { isActive: true, ...TRACKED_FILTER }) },
        { $set: { stock: effectiveStockExpr } },
        { $match: { $expr: { $lte: ['$stock', '$minStock'] } } },
        { $sort: { stock: 1 } },
        { $limit: 15 },
        { $project: { name: 1, code: 1, stock: 1, minStock: 1, sellingPrice: 1 } },
      ]),
    ]);

    const sales = salesAgg[0] || {
      totalRevenue: 0, totalProfit: 0, totalPaid: 0, totalDue: 0, totalDiscount: 0,
      totalItems: 0, count: 0,
      onlineRevenue: 0, onlineProfit: 0, onlineDue: 0, onlineCount: 0,
    };
    const expenses = expenseAgg[0] || { totalExpenses: 0, count: 0 };
    const purchases = purchaseAgg[0] || { totalPurchases: 0, totalPaid: 0, totalDue: 0, count: 0 };
    const returns = returnsAgg[0] || { totalReturns: 0, totalProfitLoss: 0, cashRefund: 0, count: 0 };

    // Due collections total
    const dueCollectionTotal = dueCollections.reduce((sum, d) => sum + d.total, 0);
    const dueCollectionCount = dueCollections.reduce((sum, d) => sum + d.count, 0);

    // Cash flow — only refunds that actually left the drawer count as cash out.
    const cashIn = quantizeMoney(sales.totalPaid + dueCollectionTotal);
    const cashOut = quantizeMoney(
      expenses.totalExpenses + purchases.totalPaid + (returns.cashRefund || 0)
    );
    const netCashFlow = quantizeMoney(cashIn - cashOut);

    // What the day EARNED, as opposed to what it took. `totalRevenue` and
    // `totalProfit` are now gross, so this is the one place the day's returns
    // are deducted — once, and on the day they happened.
    const netSales = quantizeMoney(sales.totalRevenue - returns.totalReturns);
    // কাঁচামাল খরচ for the day (CLAUDE.md §18) — a hotel's daily screen is
    // where it reads its profit, and without this its dishes show 100% margin.
    // 0 for every shop that has never issued an ingredient.
    const ingredientCost = options.withIngredientCost
      ? await ingredientService.costTotals(shopId, branchId, { start: startOfDay, end: endOfDay })
      : ingredientService.emptyCost();
    const netProfit = quantizeMoney(
      sales.totalProfit - returns.totalProfitLoss - expenses.totalExpenses - ingredientCost.total
    );

    // Build hourly chart data (0-23 hours)
    const hourlyData = [];
    for (let h = 0; h < 24; h++) {
      const hourData = salesByHour.find((d) => d._id === h);
      hourlyData.push({
        hour: h,
        label: `${h}:00`,
        revenue: hourData?.revenue || 0,
        profit: hourData?.profit || 0,
        orders: hourData?.count || 0,
      });
    }

    const result = {
      date: startOfDay.toISOString().split('T')[0],

      // Summary. `netEarnings` was profit − expenses under a name that reads
      // as "the money we actually made"; it could be positive on a day the
      // drawer went backwards. `netProfit` is what it always computed, named
      // honestly, and `netCashFlow` beside it is the money.
      // Only when there is a figure — every other shop's response keeps its shape.
      ...(ingredientCost.total > 0 ? { ingredientCost: ingredientCost.total } : {}),
      netProfit,
      netSales,
      netCashFlow,

      // Sales
      sales: {
        revenue: sales.totalRevenue,
        profit: sales.totalProfit,
        paid: sales.totalPaid,
        due: sales.totalDue,
        discount: sales.totalDiscount,
        // The invoice-level figure above and the per-line one here stay apart
        // on purpose — see the aggregation. A caller wanting "total given
        // away" adds them; one wanting to know WHERE it went cannot un-merge
        // them.
        lineDiscount: sales.totalLineDiscount,
        items: sales.totalItems,
        count: sales.count,
        byMethod: salesByMethod,
        /**
         * Where the day's selling happened.
         *
         * The offline half is `total − online`, never its own sum, so the two
         * always add back to `revenue` above no matter what a row's `channel`
         * says. A shop that has never sold online sees zeros on one side and
         * its familiar figures on the other.
         */
        byPlace: {
          online: {
            revenue: quantizeMoney(sales.onlineRevenue || 0),
            profit: quantizeMoney(sales.onlineProfit || 0),
            due: quantizeMoney(sales.onlineDue || 0),
            count: sales.onlineCount || 0,
          },
          offline: {
            revenue: quantizeMoney((sales.totalRevenue || 0) - (sales.onlineRevenue || 0)),
            profit: quantizeMoney((sales.totalProfit || 0) - (sales.onlineProfit || 0)),
            due: quantizeMoney((sales.totalDue || 0) - (sales.onlineDue || 0)),
            count: (sales.count || 0) - (sales.onlineCount || 0),
          },
        },
      },

      // Expenses
      expenses: {
        total: expenses.totalExpenses,
        count: expenses.count,
        byCategory: expenseByCategory,
      },

      // Purchases
      purchases: {
        total: purchases.totalPurchases,
        paid: purchases.totalPaid,
        due: purchases.totalDue,
        count: purchases.count,
      },

      // Due collections
      dueCollections: {
        total: dueCollectionTotal,
        count: dueCollectionCount,
        byMethod: dueCollections,
      },

      // Returns
      returns: {
        total: returns.totalReturns,
        profitLoss: returns.totalProfitLoss,
        // What of it actually left the drawer, which is the part that belongs
        // in `cashFlow.cashOut` below.
        cashRefund: returns.cashRefund || 0,
        count: returns.count,
      },

      // Cash flow
      cashFlow: {
        cashIn,
        cashOut,
        net: netCashFlow,
      },

      // Cash register
      cashRegister: cashRegister || null,

      // Charts
      hourlyData,
      topProducts,

      // Stock alerts
      lowStockProducts,
    };

    // Cache the result
    await cacheService.set(cacheKey, result, getTTL.dailySummary);
    return result;
  }

  /**
   * The three numbers the Telegram daily digest sends, per branch and in total.
   *
   * Deliberately NOT built on getDailySummary(): that runs eleven aggregations
   * to fill a dashboard, and the digest needs three columns. At 10 PM every
   * shop fires at once, so this is one aggregation per shop — grouped by
   * branch — instead of eleven per branch per shop.
   *
   * ── BOTH numbers here are GROSS, and returns are deducted separately. ────
   *
   * Read this before touching either expression; the history is instructive.
   *
   * A return writes both of its adjustments back onto the ORIGINAL `Sale`, in
   * `salesReturn.service.createReturn`:
   *
   *     returnedAmount += refund          → `netSaleAmountExpr` nets revenue
   *     profit         -= profitReduction → `$sum: '$profit'` is already net
   *
   * Reading those fields directly therefore gives numbers that are already net,
   * and the comment that used to live here said so, warning the next reader not
   * to subtract `SalesReturn.profitReduction` again and double-count.
   *
   * That warning was correct about the arithmetic and wrong about the
   * consequence it accepted: because both adjustments land on the original
   * sale, a return RE-DATES ITSELF to the day of the sale. A report for last
   * Tuesday, re-run after a Tuesday sale is returned on Friday, showed less
   * revenue and less profit than the same report did on Wednesday. It was
   * described as a deliberate accounting choice. It is not one a book can make:
   * a closed day that changes is not a record of anything, and the shop cannot
   * reconcile a period whose figures move after it ends.
   *
   * So the expressions were un-netted instead. `grossSaleAmountExpr` and
   * `grossProfitExpr` reconstruct what the invoice said on the day it was
   * written, and the day's own returns are subtracted ONCE, by the caller, on
   * the day they arrived.
   *
   * The old warning still applies in its narrow form, and matters more now:
   * subtract `profitReduction` from `$profit` and you double-count. Subtract it
   * from `grossProfitExpr()` and you are correct. The two are not
   * interchangeable — check which one you have.
   *
   * The match and the money expressions are the same ones `getDailySummary`
   * uses, so the digest total still equals what the owner sees on the
   * dashboard. Keep them in step: that equality is the point of this method.
   */
  async getDigestTotals(shopId, dateStr, { multiBranch = false } = {}) {
    const { startOfDay, endOfDay } = getBangladeshDayRange(dateStr);

    // Sales and the day's returns, bucketed the same way, so the deduction
    // below can be made per branch as well as in total.
    const [rows, returnRows] = await Promise.all([
      Sale.aggregate([
      {
        $match: {
          shop: new mongoose.Types.ObjectId(shopId),
          ...invoicedOnDayMatch(),
          createdAt: { $gte: startOfDay, $lte: endOfDay },
        },
      },
      {
        $group: {
          _id: multiBranch ? '$branch' : null,
          revenue: { $sum: grossSaleAmountExpr() },
          profit: { $sum: grossProfitExpr() },
          count: { $sum: 1 },
        },
      },
      ]),

      SalesReturn.aggregate([
        {
          $match: {
            shop: new mongoose.Types.ObjectId(shopId),
            createdAt: { $gte: startOfDay, $lte: endOfDay },
          },
        },
        {
          $group: {
            _id: multiBranch ? '$branch' : null,
            returned: { $sum: '$totalAmount' },
            returnedProfit: { $sum: '$profitReduction' },
          },
        },
      ]),
    ]);

    // One deduction, on the day the goods came back. The sale figures above are
    // gross, so this is not the double-count the header warns about — it is the
    // half of the pair that makes them net.
    const returnsById = new Map(returnRows.map((r) => [String(r._id), r]));
    const netFor = (row) => {
      const ret = returnsById.get(String(row._id)) || {};
      return {
        count: row.count || 0,
        revenue: (row.revenue || 0) - (ret.returned || 0),
        profit: (row.profit || 0) - (ret.returnedProfit || 0),
      };
    };

    // A branch with returns but no sales still has to be deducted, or a day of
    // pure refunds reports as a day when nothing happened.
    const saleKeys = new Set(rows.map((r) => String(r._id)));
    const returnOnlyRows = returnRows
      .filter((r) => !saleKeys.has(String(r._id)))
      .map((r) => ({ _id: r._id, count: 0, revenue: 0, profit: 0 }));

    const allRows = [...rows, ...returnOnlyRows];
    const total = allRows.reduce(
      (acc, r) => {
        const net = netFor(r);
        return {
          count: acc.count + net.count,
          revenue: acc.revenue + net.revenue,
          profit: acc.profit + net.profit,
        };
      },
      { count: 0, revenue: 0, profit: 0 }
    );

    const result = {
      date: dateStr,
      total: {
        count: total.count,
        revenue: quantizeMoney(total.revenue),
        profit: quantizeMoney(total.profit),
      },
      byBranch: [],
    };

    if (!multiBranch) return result;

    // Every active branch appears, including those with no sales — "0 invoices
    // at Uttara" is the line an owner most needs to see, and omitting the row
    // would read as though the branch simply wasn't counted.
    const branches = await Branch.find({ shop: shopId, isActive: true })
      .select('name')
      .sort({ isDefault: -1, name: 1 })
      .lean();

    const byId = new Map(allRows.map((r) => [String(r._id), r]));
    result.byBranch = branches.map((b) => {
      const row = byId.get(String(b._id)) || { _id: b._id, count: 0, revenue: 0, profit: 0 };
      const net = netFor(row);
      return {
        branchId: b._id,
        name: b.name,
        count: net.count,
        revenue: quantizeMoney(net.revenue),
        profit: quantizeMoney(net.profit),
      };
    });

    return result;
  }

  // Get Profit & Loss statement
  async getProfitLoss(shopId, options = {}, branchId = null) {
    const { startDate, endDate } = options;

    // Try cache first (versioned — invalidated by shop cache-version bumps)
    const plVersion = await cacheService.getShopCacheVersion(shopId);
    const cacheKey = (branchId
      ? `${KEYS.PROFIT_LOSS(shopId, startDate, endDate)}:branch:${branchId}`
      : KEYS.PROFIT_LOSS(shopId, startDate, endDate)) + `:v${plVersion}`;
    const cached = await cacheService.get(cacheKey);
    if (cached) return cached;

    const shopObjId = new mongoose.Types.ObjectId(shopId);

    const dateQuery = this._buildDateMatch(startDate, endDate);
    const dateMatch = dateQuery ? { createdAt: dateQuery } : {};
    const expenseDateMatch = dateQuery ? { date: dateQuery } : {};
    // Purchases book on `date` — the backdatable business date the purchase
    // list and supplier statement filter on — never on entry time.
    const purchaseDateMatch = dateQuery ? { date: dateQuery } : {};

    // Run all aggregations in parallel
    const [
      salesAgg,
      expenseAgg,
      expenseByCategory,
      returnsAgg,
      purchaseAgg,
      dailySales,
      dailyExpenses,
      transferCharges,
      shrinkageAgg,
      channelAgg,
    ] = await Promise.all([
      // 1. Sales: revenue, COGS, profit, count
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...invoicedOnDayMatch(),
            ...dateMatch,
          },
        },
        {
          $group: {
            _id: null,
            // Gross, as invoiced. The period's returns are a line of their own
            // below — see DAY-STABLE ACCOUNTING at the top of this file. A P&L
            // for a closed month must not change when a customer walks in
            // during the next one.
            totalRevenue: { $sum: grossSaleAmountExpr() },
            totalProfit: { $sum: grossProfitExpr() },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            // `discountAmount`, not `discount`. The latter holds "10" on a
            // percentage invoice, so summing it reported ৳10 of discount given
            // on a ৳10,000 sale — the figure was meaningless for any shop that
            // discounts by percentage. `$ifNull` falls back for invoices written
            // before the resolved amount was stored; those are overwhelmingly
            // `fixed`, where the two fields agree by definition.
            totalDiscount: { $sum: { $ifNull: ['$discountAmount', '$discount'] } },
            // ── Per-LINE discounts, which nothing used to count ───────────────
            //
            // `discountAmount` above is the INVOICE-level discount only. From
            // the moment `features.lineDiscount` shipped, a shop could knock
            // ৳10 a kilo off individual items all month and "মোট ছাড়" would
            // report ৳0 — the exact figure an owner switches the capability on
            // to watch.
            //
            // Reported as its OWN number rather than merged into the one above.
            // "I gave ৳2,000 off whole bills" and "I gave ৳8,000 off individual
            // items" are different management problems: the first is a policy,
            // the second is usually one member of staff.
            //
            // `$reduce`, not `$sum: '$items.discount'` — the latter is a valid
            // expression on an array field but silently yields 0 for documents
            // whose `items` is missing, and `$ifNull` on each line is what
            // keeps a pre-feature sale item (no `discount` key at all) from
            // turning the whole sum into null.
            totalLineDiscount: {
              $sum: {
                $reduce: {
                  input: { $ifNull: ['$items', []] },
                  initialValue: 0,
                  in: { $add: ['$$value', { $ifNull: ['$$this.discount', 0] }] },
                },
              },
            },
            // Needed to strip pass-through money out of the COGS derivation
            // below. Neither is refunded by a return, so both stay whole even on
            // a fully-returned invoice — which is exactly why subtracting them
            // from the NET revenue is correct.
            totalTax: { $sum: { $ifNull: ['$tax', 0] } },
            totalDelivery: { $sum: { $ifNull: ['$deliveryCharge', 0] } },
            count: { $sum: 1 },
          },
        },
      ]),

      // 2. Total expenses
      Expense.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...expenseDateMatch,
          },
        },
        {
          $group: {
            _id: null,
            totalExpenses: { $sum: '$amount' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 3. Expenses by category
      Expense.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...expenseDateMatch,
          },
        },
        {
          $group: {
            _id: '$category',
            categoryName: { $first: '$categoryName' },
            total: { $sum: '$amount' },
            count: { $sum: 1 },
          },
        },
        { $sort: { total: -1 } },
      ]),

      // 4. Sales returns
      SalesReturn.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...dateMatch,
          },
        },
        {
          $group: {
            _id: null,
            totalReturns: { $sum: '$totalAmount' },
            totalProfitLoss: { $sum: '$profitReduction' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 5. Purchases
      Purchase.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            ...purchaseDateMatch,
          },
        },
        {
          $group: {
            _id: null,
            totalPurchases: { $sum: '$totalAmount' },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            count: { $sum: 1 },
          },
        },
      ]),

      // 6. Daily sales breakdown (for chart). Same gross basis as the summary
      // above, so a bar on the chart and the total beside it never disagree.
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...invoicedOnDayMatch(),
            ...dateMatch,
          },
        },
        {
          $group: {
            _id: {
              $dateToString: { format: '%Y-%m-%d', date: '$createdAt', timezone: BD_TZ },
            },
            revenue: { $sum: grossSaleAmountExpr() },
            profit: { $sum: grossProfitExpr() },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // 7. Daily expenses breakdown (for chart)
      Expense.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...expenseDateMatch,
          },
        },
        {
          $group: {
            _id: {
              // Must stay in step with the sales bucket above — the P&L chart
              // joins the two series on this key, so a UTC expense day against a
              // BD sales day would misalign cost from revenue by six hours.
              $dateToString: { format: '%Y-%m-%d', date: '$date', timezone: BD_TZ },
            },
            expense: { $sum: '$amount' },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // 8. What the shop paid to move its own money — the MFS and bank fees.
      //
      // `$subtract` on the two sides of each transfer, summed. The charge is
      // never stored: `amountOut - amountIn` is the only definition that cannot
      // drift from the figures it is computed from, which is the same rule the
      // grand balance total follows.
      //
      // Bounded by `date` — the day the money moved, not the day it was typed.
      AccountTransfer.aggregate([
        {
          $match: {
            shop: shopObjId,
            // A voided transfer's fee was never really paid — it was a typo.
            ...LIVE_TRANSFER,
            ...(branchId ? { branch: new mongoose.Types.ObjectId(branchId) } : {}),
            ...(dateQuery ? { date: dateQuery } : {}),
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: { $subtract: ['$amountOut', '$amountIn'] } },
          },
        },
      ]),

      /**
       * 9. ক্ষতি — stock written off as a loss.
       *
       * ── Why this cannot be derived and has to be its own query ────────────
       *
       * `cogs` above is `merchandiseRevenue − Sale.profit`. That identity comes
       * out of `Sale.pre('save')`, which builds profit from line margins — so
       * by construction it can only ever contain the cost of goods that were
       * SOLD. Goods that expired, broke or walked out of the door never appear
       * in a Sale, so no amount of rearranging the sales figures can find them.
       * They are only in the stock ledger, which is where this reads them from.
       *
       * `totalCost` was snapshotted onto each row at write-off time from the
       * cost basis of the day (product.service.writeOffStock). Re-deriving it
       * here from today's `buyingPrice` would revalue a closed month's loss
       * every time a supplier moved their price.
       *
       * Grouped by reason as well as summed, because the split is the whole
       * management value: "৳12,000 lost" is a number an owner can do nothing
       * with, and "৳9,000 of it expired" tells them to order smaller and more
       * often.
       *
       * ZERO for every shop that has never written anything off — which on the
       * day this shipped was all of them — so `netProfit` is unchanged until
       * the feature is used.
       */
      StockTransaction.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            type: 'damage',
            ...dateMatch,
          },
        },
        {
          $group: {
            _id: '$writeOffReason',
            total: { $sum: { $ifNull: ['$totalCost', 0] } },
            count: { $sum: 1 },
          },
        },
        { $sort: { total: -1 } },
      ]),

      /**
       * 10. WHERE THE MONEY CAME FROM — the online/offline split.
       *
       * The shop app could already FILTER a sales list by online/offline, but
       * no report anywhere grouped by it, so "কত অনলাইন থেকে, কত অফলাইন থেকে"
       * had no answer — for a product sold as running both counters at once,
       * that is the headline question.
       *
       * ── Why the key is computed rather than just `$channel` ────────────────
       *
       * `channel` defaults to `'pos'` and `isOnline` defaults to false, but they
       * are independent fields and the pair disagrees on real rows: an early
       * client could post `channel: 'facebook'` without setting `isOnline`.
       * Grouping on `channel` alone would then count that sale as a shop sale;
       * grouping on `isOnline` alone would throw away which channel it was.
       * Trusting `isOnline` for the split and `channel` for the label is what
       * makes the two sub-totals add up to the headline revenue, which is the
       * only property that makes this table believable.
       *
       * ── `fromOrders` ───────────────────────────────────────────────────────
       *
       * How many of these have a real `Order` behind them. It exists because
       * `isOnline` covers two different things — a parcel with a worklist row,
       * and a sale a cashier ticked "online" on at the till — and a shop
       * reconciling its worklist against its books needs to see the gap rather
       * than have it averaged away. Once `sale.service`'s one-door guard has
       * been in place for a while this should equal `count` for every online
       * row; while it does not, the difference is exactly the till-typed
       * backlog.
       */
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...invoicedOnDayMatch(),
            ...dateMatch,
          },
        },
        {
          $group: {
            _id: {
              isOnline: { $eq: ['$isOnline', true] },
              // An online sale keeps its own channel; everything else is the
              // counter, whatever the row happens to say.
              channel: {
                $cond: [
                  { $eq: ['$isOnline', true] },
                  { $ifNull: ['$channel', 'other'] },
                  'pos',
                ],
              },
            },
            revenue: { $sum: grossSaleAmountExpr() },
            grossProfit: { $sum: grossProfitExpr() },
            tax: { $sum: { $ifNull: ['$tax', 0] } },
            delivery: { $sum: { $ifNull: ['$deliveryCharge', 0] } },
            discount: { $sum: { $ifNull: ['$discountAmount', '$discount'] } },
            due: { $sum: { $ifNull: ['$due', 0] } },
            count: { $sum: 1 },
            fromOrders: {
              $sum: { $cond: [{ $ifNull: ['$order', false] }, 1, 0] },
            },
          },
        },
        { $sort: { revenue: -1 } },
      ]),
    ]);

    const sales = salesAgg[0] || {
      totalRevenue: 0, totalProfit: 0, totalPaid: 0, totalDue: 0,
      totalDiscount: 0, totalTax: 0, totalDelivery: 0, count: 0,
    };
    const expenses = expenseAgg[0] || { totalExpenses: 0, count: 0 };
    const returns = returnsAgg[0] || { totalReturns: 0, totalProfitLoss: 0, count: 0 };
    const purchases = purchaseAgg[0] || { totalPurchases: 0, totalPaid: 0, totalDue: 0, count: 0 };

    /**
     * ── COGS is derived from MERCHANDISE revenue, not from total revenue ──────
     *
     * This was `totalRevenue - totalProfit`, and the identity it relied on does
     * not hold: `revenue` sums `Sale.total`, which includes `tax` and
     * `deliveryCharge`, while `Sale.profit` counts neither of them (see the
     * pre-save hook — profit is built from line margins less discounts). So
     * every taka of delivery the shop billed, and every taka of tax it merely
     * collected on someone else's behalf, was reported as cost of goods sold.
     *
     * For a shop doing home delivery that is not a rounding error: the whole
     * delivery line lands in COGS and gross margin reads far worse than it is.
     *
     * Stripping both terms leaves the merchandise revenue the margin actually
     * came from, and the three figures now tie out exactly —
     * `merchandiseRevenue - cogs === grossProfit` — because that identity is
     * what `Sale.pre('save')` computes per invoice.
     */
    const merchandiseRevenue = quantizeMoney(
      Math.max(0, sales.totalRevenue - (sales.totalTax || 0) - (sales.totalDelivery || 0))
    );
    const cogs = quantizeMoney(Math.max(0, merchandiseRevenue - sales.totalProfit));

    /**
     * Net profit = Gross profit - Returns - Expenses - Charges - Shrinkage.
     *
     * `returns.totalProfitLoss` IS subtracted here, and the history of this one
     * line is worth keeping. It used not to be, correctly: `createReturn`
     * decrements `profit` on the original Sale, so a `$sum: '$profit'` was
     * already net of every return ever raised against the period, and
     * subtracting again would have double-counted.
     *
     * The cost of that was a P&L that restated itself. A return raised in
     * October reached back and reduced August's profit, so August's statement
     * was a different document every time it was opened. `totalProfit` is now
     * `grossProfitExpr()` — as invoiced, before any return — so the deduction
     * happens here instead, once, against the period the goods actually came
     * back in.
     *
     * Which figure you have decides whether subtracting is right. Against
     * `$profit`: double-counts. Against `grossProfitExpr()`: correct. They are
     * not interchangeable.
     *
     * It is still reported, as `returnsLoss` below — an owner wants to see how
     * much of the month walked back through the door, and cannot read that off
     * a profit figure it has already been removed from.
     */
    /**
     * What the shop paid to move its own money.
     *
     * A bKash cash-out costs ~1.85%; a shop turning over ৳5 lakh a month
     * through MFS is handing over ~৳9,000 that appeared in no report anywhere.
     * It is a genuine cost of trading, so it belongs in `netProfit`.
     *
     * ── Why it is NOT an expense row ─────────────────────────────────────────
     *
     * Writing an `Expense` for each charge would be double counting: the
     * transfer already debits the from-account by the full `amountOut`, and the
     * cash register already sums `amountOut` as cash leaving the drawer. The
     * charge is the gap between the two sides of one movement, not a third
     * movement, so it is summed here from the transfers themselves.
     *
     * Zero for every shop without `features.fundAccounts` — they have no
     * transfers — so `netProfit` is unchanged for them (I-1).
     */
    const charges = transferCharges[0]?.total || 0;

    /**
     * ── ক্ষতি: the cost of goods that never got sold ─────────────────────────
     *
     * This is the term `netProfit` was missing. `grossProfit` is margin on
     * goods that LEFT through the till; `shrinkage` is the cost of goods that
     * left any other way — expired, broke, or walked. Both reduce what the
     * owner is actually left with at the end of the month, and only one of them
     * used to be counted.
     *
     * ── Why it is subtracted here and not folded into `cogs` ────────────────
     *
     * Because `merchandiseRevenue − cogs === grossProfit` is an identity that
     * has to keep holding — it is what `Sale.pre('save')` computes per invoice,
     * and the P&L strips tax and delivery out of revenue specifically so the
     * three figures tie out. Adding shrinkage to `cogs` would break that tie
     * and make gross margin unreadable, since there is no revenue on the other
     * side of a write-off to earn it against.
     *
     * So it sits beside `totalExpenses` and `transferCharges` as a third thing
     * that comes off gross profit — reported on its own line, for the same
     * reason those two are: an owner can act on "৳9,000 of stock expired this
     * month" and cannot act on the same ৳9,000 buried inside cost of sales.
     */
    const shrinkage = quantizeMoney(
      (shrinkageAgg || []).reduce((sum, r) => sum + (r.total || 0), 0)
    );

    /**
     * কাঁচামাল খরচ — what the kitchen used (CLAUDE.md §18). A restaurant's
     * dishes carry no buying price; their cost reaches the P&L here, on the day
     * the rice was COOKED, never on the day it was bought (purchases have never
     * been a P&L term). Its own line for the same reason as `shrinkage`.
     *
     * 0 for every shop that has never issued an ingredient, so `netProfit` is
     * unchanged for them — and the key below is only added when there is a
     * figure, so their response keeps its shape.
     */
    // Queried only for a restaurant (`options.withIngredientCost`, set by the
    // controller from `features.restaurant`) — every other shop runs exactly
    // the queries it always did (M-12).
    const ingredientCost = options.withIngredientCost
      ? await ingredientService.costTotals(shopId, branchId, {
        start: dateQuery?.$gte, end: dateQuery?.$lte,
      })
      : ingredientService.emptyCost();

    const netProfit = quantizeMoney(
      sales.totalProfit - returns.totalProfitLoss - expenses.totalExpenses - charges - shrinkage
        - ingredientCost.total
    );

    // Merge daily sales and expenses into a single chart dataset
    const dailyMap = new Map();
    for (const d of dailySales) {
      dailyMap.set(d._id, { date: d._id, revenue: d.revenue, profit: d.profit, orders: d.count, expense: 0 });
    }
    for (const d of dailyExpenses) {
      if (dailyMap.has(d._id)) {
        dailyMap.get(d._id).expense = d.expense;
      } else {
        dailyMap.set(d._id, { date: d._id, revenue: 0, profit: 0, orders: 0, expense: d.expense });
      }
    }
    const chartData = Array.from(dailyMap.values()).sort((a, b) => a.date.localeCompare(b.date));

    // Gross sales less what came back: the "net sales" line of an ordinary
    // statement. `revenue` stays GROSS because `merchandiseRevenue` and `cogs`
    // are derived from it and the identity
    // `merchandiseRevenue - cogs === grossProfit` is what `Sale.pre('save')`
    // computes per invoice — netting returns into it would break the tie-out
    // while looking tidier.
    const netRevenue = quantizeMoney(sales.totalRevenue - returns.totalReturns);

    /**
     * The channel table, shaped so it can be read beside the headline figures
     * without the reader doing arithmetic in their head.
     *
     * COGS per row is derived the SAME way as the headline — merchandise
     * revenue (gross, less tax and delivery) minus gross profit — so
     * `Σ row.merchandiseRevenue − Σ row.cogs === grossProfit` holds for exactly
     * the reason the top-level identity does. Deriving it any other way here
     * would produce a table that does not add up to the statement above it,
     * which is worse than no table.
     *
     * Returns are deliberately NOT split out per channel. `SalesReturn` carries
     * no channel of its own and reaching through to the original sale would
     * make a return move between rows depending on when it was raised — the
     * day-stability problem this file already solved once. So the rows are
     * gross-as-invoiced, and the label says so.
     */
    const byChannel = (channelAgg || []).map((row) => {
      const revenue = quantizeMoney(row.revenue || 0);
      const rowTax = quantizeMoney(row.tax || 0);
      const rowDelivery = quantizeMoney(row.delivery || 0);
      const rowMerchandise = quantizeMoney(Math.max(0, revenue - rowTax - rowDelivery));
      const rowGrossProfit = quantizeMoney(row.grossProfit || 0);
      return {
        channel: row._id?.channel || 'other',
        isOnline: row._id?.isOnline === true,
        revenue,
        merchandiseRevenue: rowMerchandise,
        cogs: quantizeMoney(Math.max(0, rowMerchandise - rowGrossProfit)),
        grossProfit: rowGrossProfit,
        tax: rowTax,
        deliveryCharge: rowDelivery,
        discount: quantizeMoney(row.discount || 0),
        due: quantizeMoney(row.due || 0),
        count: row.count || 0,
        // Only meaningful for online rows; always 0 for `pos`, where there is
        // no order to have come from.
        fromOrders: row.fromOrders || 0,
      };
    });

    /** Roll the table up into the two numbers the question is actually about. */
    const rollup = (rows) => rows.reduce(
      (acc, r) => ({
        revenue: quantizeMoney(acc.revenue + r.revenue),
        merchandiseRevenue: quantizeMoney(acc.merchandiseRevenue + r.merchandiseRevenue),
        cogs: quantizeMoney(acc.cogs + r.cogs),
        grossProfit: quantizeMoney(acc.grossProfit + r.grossProfit),
        deliveryCharge: quantizeMoney(acc.deliveryCharge + r.deliveryCharge),
        due: quantizeMoney(acc.due + r.due),
        count: acc.count + r.count,
        fromOrders: acc.fromOrders + r.fromOrders,
      }),
      {
        revenue: 0, merchandiseRevenue: 0, cogs: 0, grossProfit: 0,
        deliveryCharge: 0, due: 0, count: 0, fromOrders: 0,
      }
    );

    const channelSplit = {
      online: rollup(byChannel.filter((r) => r.isOnline)),
      offline: rollup(byChannel.filter((r) => !r.isOnline)),
      byChannel,
    };

    const result = {
      // Summary
      revenue: sales.totalRevenue,
      netRevenue,
      // Revenue less the two pass-through lines. Exposed so the P&L can show
      // why `revenue - cogs` is not `grossProfit` when a shop bills delivery.
      merchandiseRevenue,
      tax: sales.totalTax || 0,
      deliveryCharge: sales.totalDelivery || 0,
      cogs,
      grossProfit: sales.totalProfit,
      totalExpenses: expenses.totalExpenses,
      returnsLoss: returns.totalProfitLoss,
      // Reported on its own line rather than folded into `totalExpenses`.
      // "I spent ৳40,000 running the shop" and "I paid ৳9,000 to move my own
      // money around" are different management problems: the second is usually
      // fixable by banking less often or using a different channel, and merging
      // it into expenses hides that it is fixable at all.
      transferCharges: charges,
      // ক্ষতি. Its own line beside `returnsLoss` — goods that walked back
      // through the door and goods that never made it out are both losses the
      // owner can do something about, and they call for different actions.
      shrinkage,
      ...(ingredientCost.total > 0 ? { ingredientCost } : {}),
      netProfit,

      /**
       * Online vs offline, and the per-channel breakdown behind it.
       *
       * `channelSplit.online.revenue + channelSplit.offline.revenue === revenue`
       * by construction — both come from one pass over the same matched set as
       * the headline figures — so the table can be trusted to reconcile with
       * the statement it sits under. Enforced by test, not by hope.
       */
      channelSplit,

      // Details
      sales: {
        revenue: sales.totalRevenue,
        paid: sales.totalPaid,
        due: sales.totalDue,
        discount: sales.totalDiscount,
        lineDiscount: sales.totalLineDiscount,
        count: sales.count,
        profit: sales.totalProfit,
      },
      expenses: {
        total: expenses.totalExpenses,
        count: expenses.count,
        byCategory: expenseByCategory,
      },
      returns: {
        total: returns.totalReturns,
        profitLoss: returns.totalProfitLoss,
        count: returns.count,
      },
      // The reason split. An empty array for a shop that has written nothing
      // off, which is what lets the client hide the panel entirely rather than
      // render a section of zeroes at every shop that will never use it.
      //
      // `totalCost`, not `total`, on both levels — deliberately. That key is
      // already in the sanitiser's `COST_KEYS`, so a staff member without
      // `products.view_cost` cannot read these. It matters: a write-off row
      // carries a quantity, so anyone who can see its value can divide the two
      // and recover the buying price this shop keeps from them. Naming it
      // `total` would have leaked the cost basis through a report that never
      // mentions cost. Same trap the `packUnitCost` note in that file describes.
      writeOffs: {
        totalCost: shrinkage,
        byReason: (shrinkageAgg || []).map((r) => ({
          reason: r._id,
          totalCost: quantizeMoney(r.total || 0),
          count: r.count,
        })),
      },
      purchases: {
        total: purchases.totalPurchases,
        paid: purchases.totalPaid,
        due: purchases.totalDue,
        count: purchases.count,
      },

      // Chart
      chartData,
    };

    // Cache the result
    await cacheService.set(cacheKey, result, getTTL.profitLoss);
    return result;
  }

  // Get Date-wise Summary for a month (scrollable table)
  async getDateWiseSummary(shopId, options = {}, branchId = null) {
    const { month } = options; // format: 'YYYY-MM'

    // Determine start and end of the month in BD time
    let year, mon;
    if (month) {
      [year, mon] = month.split('-').map(Number);
    } else {
      const bdNow = new Date(Date.now() + BD_OFFSET_MS);
      year = bdNow.getFullYear();
      mon = bdNow.getMonth() + 1;
    }

    // First and last day of month in BD timezone
    const startOfMonth = new Date(Date.UTC(year, mon - 1, 1) - BD_OFFSET_MS);
    const lastDay = new Date(year, mon, 0).getDate(); // last day of month
    const endOfMonth = new Date(Date.UTC(year, mon - 1, lastDay + 1) - BD_OFFSET_MS - 1);

    // Bucket a date field into Bangladesh calendar days. `timezone` is not
    // optional — `$dateToString` defaults to UTC, which puts the first six
    // hours of every Dhaka day on the day before (see reportDateBuckets.test).
    const dayBucket = (dateExpr) => ({
      $dateToString: { format: '%Y-%m-%d', date: dateExpr, timezone: BD_TZ },
    });

    // Five books, each keyed on the day the thing ACTUALLY happened:
    // sales on the invoice date, returns on the day they came back, expenses
    // and purchases on their business date, collections on `paidAt`.
    const [dailySales, dailyExpenses, dailyReturns, dailyCollections, dailyPurchases] =
      await Promise.all([
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            ...invoicedOnDayMatch(),
            createdAt: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: dayBucket('$createdAt'),
            // Gross, not net: a return is booked on the day it arrived, below.
            // Netting it here as well would take the same refund off twice.
            totalSales: { $sum: grossSaleAmountExpr() },
            totalProfit: { $sum: grossProfitExpr() },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            orderCount: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      Expense.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            date: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: dayBucket('$date'),
            totalExpenses: { $sum: '$amount' },
            expenseCount: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // Returns, on the day the goods came back — NOT on the day of the sale
      // they came off. `cashRefund` is separated because only a cash refund
      // moves money: an `adjustment` writes the customer's খাতা down and a
      // `store_credit` moves nothing at all until it is settled later.
      SalesReturn.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            createdAt: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: dayBucket('$createdAt'),
            returnAmount: { $sum: '$totalAmount' },
            returnProfitLoss: { $sum: '$profitReduction' },
            cashRefund: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      { $eq: ['$refundMethod', 'cash'] },
                      { $eq: ['$refundStatus', 'settled'] },
                    ],
                  },
                  '$totalAmount',
                  0,
                ],
              },
            },
            returnCount: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // বাকি আদায় — money for invoices written on some earlier day, which is
      // exactly the cash this report could not see. Keyed on the effective
      // date, so a Saturday collection entered on Monday lands on Saturday.
      Payment.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            type: 'due_collection',
            ...LIVE_PAYMENT,
            ...paidAtMatch({ $gte: startOfMonth, $lte: endOfMonth }),
          },
        },
        {
          $group: {
            _id: dayBucket(PAID_AT_EXPR),
            collected: { $sum: '$amount' },
            collectionCount: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // Money paid to suppliers. `date` and not `createdAt` for the reason the
      // daily summary documents: a purchase is backdatable and belongs on the
      // day the goods were bought.
      Purchase.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            date: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: dayBucket('$date'),
            purchasePaid: { $sum: '$paid' },
            purchaseTotal: { $sum: '$totalAmount' },
            purchaseCount: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
    ]);

    // Build the days array for the entire month.
    // Indexed once rather than re-scanned per day: the `.find()` calls that
    // used to sit inside this loop made it O(days x rows).
    const salesByDate = new Map(dailySales.map((r) => [r._id, r]));
    const expensesByDate = new Map(dailyExpenses.map((r) => [r._id, r]));
    const returnsByDate = new Map(dailyReturns.map((r) => [r._id, r]));
    const collectionsByDate = new Map(dailyCollections.map((r) => [r._id, r]));
    const purchasesByDate = new Map(dailyPurchases.map((r) => [r._id, r]));

    const days = [];
    const total = {
      sales: 0, returns: 0, expenses: 0, grossProfit: 0, returnsLoss: 0,
      cashIn: 0, cashOut: 0, orderCount: 0, purchasePaid: 0, collected: 0,
      salesPaid: 0, cashRefund: 0,
    };

    for (let d = 1; d <= lastDay; d++) {
      const dateStr = `${year}-${String(mon).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const saleRow = salesByDate.get(dateStr);
      const expenseRow = expensesByDate.get(dateStr);
      const returnRow = returnsByDate.get(dateStr);
      const collectionRow = collectionsByDate.get(dateStr);
      const purchaseRow = purchasesByDate.get(dateStr);

      // ── Book 1: performance. What the day earned, final once it closes. ──
      const sales = saleRow?.totalSales || 0;
      const returns = returnRow?.returnAmount || 0;
      const grossProfit = saleRow?.totalProfit || 0;
      const returnsLoss = returnRow?.returnProfitLoss || 0;
      const expenses = expenseRow?.totalExpenses || 0;

      // ── Book 2: cash. What actually moved, which is a different number. ──
      //
      // A day of বাকি sales earns profit and takes no money; a day of বাকি
      // আদায় takes money and earns nothing. Reporting only the first is what
      // made "আসল আয়" read positive on a day the drawer went backwards.
      const salesPaid = saleRow?.totalPaid || 0;
      const collected = collectionRow?.collected || 0;
      const purchasePaid = purchaseRow?.purchasePaid || 0;
      const cashRefund = returnRow?.cashRefund || 0;

      const cashIn = quantizeMoney(salesPaid + collected);
      const cashOut = quantizeMoney(expenses + purchasePaid + cashRefund);

      total.sales += sales;
      total.returns += returns;
      total.expenses += expenses;
      total.grossProfit += grossProfit;
      total.returnsLoss += returnsLoss;
      total.salesPaid += salesPaid;
      total.collected += collected;
      total.purchasePaid += purchasePaid;
      total.cashRefund += cashRefund;
      total.cashIn += cashIn;
      total.cashOut += cashOut;
      total.orderCount += saleRow?.orderCount || 0;

      days.push({
        date: dateStr,
        // Performance
        sales,
        returns,
        netSales: quantizeMoney(sales - returns),
        profit: grossProfit,
        returnsLoss,
        expenses,
        netProfit: quantizeMoney(grossProfit - returnsLoss - expenses),
        // Cash
        cashIn,
        cashOut,
        netCash: quantizeMoney(cashIn - cashOut),
        salesPaid,
        collected,
        purchasePaid,
        cashRefund,
        // Counts
        due: saleRow?.totalDue || 0,
        orderCount: saleRow?.orderCount || 0,
        expenseCount: expenseRow?.expenseCount || 0,
        returnCount: returnRow?.returnCount || 0,
        collectionCount: collectionRow?.collectionCount || 0,
        purchaseCount: purchaseRow?.purchaseCount || 0,
      });
    }

    return {
      month: `${year}-${String(mon).padStart(2, '0')}`,
      days,
      monthTotal: {
        sales: quantizeMoney(total.sales),
        returns: quantizeMoney(total.returns),
        netSales: quantizeMoney(total.sales - total.returns),
        profit: quantizeMoney(total.grossProfit),
        returnsLoss: quantizeMoney(total.returnsLoss),
        expenses: quantizeMoney(total.expenses),
        netProfit: quantizeMoney(total.grossProfit - total.returnsLoss - total.expenses),
        cashIn: quantizeMoney(total.cashIn),
        cashOut: quantizeMoney(total.cashOut),
        netCash: quantizeMoney(total.cashIn - total.cashOut),
        salesPaid: quantizeMoney(total.salesPaid),
        collected: quantizeMoney(total.collected),
        purchasePaid: quantizeMoney(total.purchasePaid),
        cashRefund: quantizeMoney(total.cashRefund),
        orderCount: total.orderCount,
      },
    };
  }

  /**
   * ───────────────────────────────────────────────────────────────────────────
   * THE MONTH BOOK — one row per month, and one column per branch
   * ───────────────────────────────────────────────────────────────────────────
   *
   * `getDateWiseSummary` above answers "how did this month go, day by day".
   * This answers the question an owner asks once the month has closed: "how are
   * we doing, month by month, and which branch is carrying it".
   *
   * ── Why this is not the date-wise report called twelve times ───────────────
   *
   * It could be, and for a single-branch shop the numbers would agree. What it
   * could not do is the second half of the question. A shop with four branches
   * asking for two years of history is 96 (month × branch) cells; fetched as 96
   * calls that is 480 aggregations, and fetched as 24 shop-wide calls it does
   * not contain the branch dimension at all. Grouping by `(month, branch)` gets
   * every cell out of the same five passes the single-month report already
   * does, and the shop-wide row is then the SUM of the branch cells rather than
   * a sixth query that could disagree with them.
   *
   * ── The five books are the SAME five, keyed the same way ───────────────────
   *
   * Sales on the invoice date, returns on the day they came back, expenses and
   * purchases on their business date, collections on `paidAt`. Every definition
   * here is lifted from `getDateWiseSummary` deliberately and must stay lifted:
   * an owner who opens this report and then opens তারিখ অনুসারে for one of its
   * months is checking one against the other, and a month total that does not
   * equal the sum of its own days is worse than no month total. `%Y-%m` instead
   * of `%Y-%m-%d` is the only difference between the two pipelines.
   *
   * The DAY-STABLE ACCOUNTING note at the top of this file governs here in
   * full, and more sharply: a month book is read months after the fact, so a
   * figure that restates itself is not an annoyance but the whole defect.
   *
   * ── Branches that closed still have history ────────────────────────────────
   *
   * The branch axis comes from the AGGREGATION, not from the branch list, and
   * the list is used only to put a name on each id. A branch deactivated in
   * March still sold goods in February, and dropping its column would quietly
   * reduce every shop-wide total that includes it — the one thing this report
   * must never do. An id with no matching branch document is labelled rather
   * than discarded.
   *
   * @param {string} shopId
   * @param {{ from?: string, to?: string, months?: number }} options
   *        `from`/`to` are inclusive 'YYYY-MM'. Given neither, the window is
   *        the last `months` months ending with the current one.
   * @param {string|null} branchId  a single branch, when the reader is scoped
   *        to one. The branch breakdown is then that branch alone.
   * @param {boolean} withBranchBreakdown  whether to group by branch at all.
   *        False for a single-branch shop, where the extra key buys nothing.
   */
  async getMonthWiseSummary(shopId, options = {}, branchId = null, withBranchBreakdown = false) {
    const { from, to } = this._monthWindow(options);

    // The branch axis is part of the ANSWER, so it is part of the key. A reader
    // scoped to one branch and the owner looking shop-wide must not share an
    // entry — the rule every branch-scoped report on this service follows.
    const mwVersion = await cacheService.getShopCacheVersion(shopId);
    const cacheKey = `${KEYS.MONTH_WISE(shopId, from, to)}`
      + `:branch:${branchId || 'all'}`
      + `:split:${withBranchBreakdown ? 1 : 0}`
      + `:v${mwVersion}`;
    const cached = await cacheService.get(cacheKey);
    if (cached) return cached;

    const [fromYear, fromMon] = from.split('-').map(Number);
    const [toYear, toMon] = to.split('-').map(Number);

    // Both edges in BD time, for the reason `getDateWiseSummary` builds its own
    // boundaries: a window computed in UTC starts and ends six hours off, which
    // moves the first and last evening of the range into the neighbouring month.
    const startOfWindow = new Date(Date.UTC(fromYear, fromMon - 1, 1) - BD_OFFSET_MS);
    const lastDay = new Date(toYear, toMon, 0).getDate();
    const endOfWindow = new Date(Date.UTC(toYear, toMon - 1, lastDay + 1) - BD_OFFSET_MS - 1);

    /**
     * The group key: month, and branch when the shop has more than one.
     *
     * `$branch` is emitted as its own field rather than folded into the string
     * key so the id survives as an ObjectId and can be matched against the
     * branch list without parsing it back out of a label.
     */
    const bucket = (dateExpr) => ({
      month: { $dateToString: { format: '%Y-%m', date: dateExpr, timezone: BD_TZ } },
      ...(withBranchBreakdown ? { branch: '$branch' } : {}),
    });

    const window = { $gte: startOfWindow, $lte: endOfWindow };

    const [monthSales, monthExpenses, monthReturns, monthCollections, monthPurchases] =
      await Promise.all([
        Sale.aggregate([
          {
            $match: {
              ...this._baseMatch(shopId, branchId),
              ...invoicedOnDayMatch(),
              createdAt: window,
            },
          },
          {
            $group: {
              _id: bucket('$createdAt'),
              // Gross, as invoiced. The window's returns are their own book
              // below, booked in the month they arrived — netting here too
              // would take the same refund off twice.
              totalSales: { $sum: grossSaleAmountExpr() },
              totalProfit: { $sum: grossProfitExpr() },
              totalPaid: { $sum: '$paid' },
              totalDue: { $sum: '$due' },
              orderCount: { $sum: 1 },
            },
          },
        ]),

        Expense.aggregate([
          {
            $match: {
              ...this._baseMatch(shopId, branchId),
              date: window,
            },
          },
          {
            $group: {
              _id: bucket('$date'),
              totalExpenses: { $sum: '$amount' },
              expenseCount: { $sum: 1 },
            },
          },
        ]),

        SalesReturn.aggregate([
          {
            $match: {
              ...this._baseMatch(shopId, branchId),
              createdAt: window,
            },
          },
          {
            $group: {
              _id: bucket('$createdAt'),
              returnAmount: { $sum: '$totalAmount' },
              returnProfitLoss: { $sum: '$profitReduction' },
              // Only a cash refund moves money. An adjustment writes the
              // customer's খাতা down and a store credit moves nothing until it
              // is spent, so neither belongs in the cash column.
              cashRefund: {
                $sum: {
                  $cond: [
                    {
                      $and: [
                        { $eq: ['$refundMethod', 'cash'] },
                        { $eq: ['$refundStatus', 'settled'] },
                      ],
                    },
                    '$totalAmount',
                    0,
                  ],
                },
              },
              returnCount: { $sum: 1 },
            },
          },
        ]),

        // বাকি আদায় — money against invoices from earlier months, which is
        // most of what makes a month's cash differ from its sales.
        Payment.aggregate([
          {
            $match: {
              ...this._baseMatch(shopId, branchId),
              type: 'due_collection',
              ...LIVE_PAYMENT,
              ...paidAtMatch(window),
            },
          },
          {
            $group: {
              _id: bucket(PAID_AT_EXPR),
              collected: { $sum: '$amount' },
              collectionCount: { $sum: 1 },
            },
          },
        ]),

        Purchase.aggregate([
          {
            $match: {
              ...this._baseMatch(shopId, branchId),
              status: { $ne: 'cancelled' },
              date: window,
            },
          },
          {
            $group: {
              _id: bucket('$date'),
              purchasePaid: { $sum: '$paid' },
              purchaseTotal: { $sum: '$totalAmount' },
              purchaseCount: { $sum: 1 },
            },
          },
        ]),
      ]);

    // Names for the ids the aggregation returned. `getShopBranches` is the
    // label source and NOT the axis — see the note above on branches that have
    // closed since the months being reported.
    const branchNames = new Map();
    if (withBranchBreakdown) {
      const branches = await Branch.getShopBranches(shopId);
      for (const b of branches) branchNames.set(String(b._id), b.name);
    }

    const rowKey = (row) => `${row._id.month}|${row._id.branch ? String(row._id.branch) : 'shop'}`;
    const index = (rows) => new Map(rows.map((r) => [rowKey(r), r]));

    const salesBy = index(monthSales);
    const expensesBy = index(monthExpenses);
    const returnsBy = index(monthReturns);
    const collectionsBy = index(monthCollections);
    const purchasesBy = index(monthPurchases);

    /**
     * Every branch id that appears in ANY of the five books, ordered by the
     * branch list.
     *
     * Taken from the books and not from the branch list because a branch with
     * no sales in the window may still have had an expense, and because of the
     * closed-branch rule above. The branch list decides only the ORDER, so the
     * columns do not shuffle between two loads of the same report.
     */
    const branchIds = [];
    if (withBranchBreakdown) {
      const seen = new Set();
      for (const rows of [monthSales, monthExpenses, monthReturns, monthCollections, monthPurchases]) {
        for (const r of rows) {
          const id = r._id.branch ? String(r._id.branch) : null;
          if (id && !seen.has(id)) { seen.add(id); branchIds.push(id); }
        }
      }
      const order = new Map([...branchNames.keys()].map((id, i) => [id, i]));
      branchIds.sort((a, b) => (order.get(a) ?? Infinity) - (order.get(b) ?? Infinity));
    }

    /** The raw figures for one (month, branch) cell, from the five books. */
    const cellFor = (month, branch) => {
      const k = `${month}|${branch || 'shop'}`;
      const s = salesBy.get(k);
      const e = expensesBy.get(k);
      const r = returnsBy.get(k);
      const c = collectionsBy.get(k);
      const p = purchasesBy.get(k);

      return {
        // Book 1: performance. What the month earned, final once it closes.
        sales: s?.totalSales || 0,
        returns: r?.returnAmount || 0,
        grossProfit: s?.totalProfit || 0,
        returnsLoss: r?.returnProfitLoss || 0,
        expenses: e?.totalExpenses || 0,
        // Book 2: cash. What actually moved, which is a different number — see
        // the note in getDateWiseSummary. A month of বাকি sales earns profit
        // and takes no money; a month of বাকি আদায় takes money and earns none.
        salesPaid: s?.totalPaid || 0,
        collected: c?.collected || 0,
        purchasePaid: p?.purchasePaid || 0,
        cashRefund: r?.cashRefund || 0,
        purchaseTotal: p?.purchaseTotal || 0,
        due: s?.totalDue || 0,
        orderCount: s?.orderCount || 0,
        expenseCount: e?.expenseCount || 0,
        returnCount: r?.returnCount || 0,
        collectionCount: c?.collectionCount || 0,
        purchaseCount: p?.purchaseCount || 0,
      };
    };

    /** A raw cell, presented — the derived lines an owner actually reads. */
    const present = (month, raw) => {
      const cashIn = raw.salesPaid + raw.collected;
      const cashOut = raw.expenses + raw.purchasePaid + raw.cashRefund;
      return {
        month,
        // Performance
        sales: quantizeMoney(raw.sales),
        returns: quantizeMoney(raw.returns),
        netSales: quantizeMoney(raw.sales - raw.returns),
        profit: quantizeMoney(raw.grossProfit),
        returnsLoss: quantizeMoney(raw.returnsLoss),
        expenses: quantizeMoney(raw.expenses),
        netProfit: quantizeMoney(raw.grossProfit - raw.returnsLoss - raw.expenses),
        // Cash
        cashIn: quantizeMoney(cashIn),
        cashOut: quantizeMoney(cashOut),
        netCash: quantizeMoney(cashIn - cashOut),
        salesPaid: quantizeMoney(raw.salesPaid),
        collected: quantizeMoney(raw.collected),
        purchasePaid: quantizeMoney(raw.purchasePaid),
        purchases: quantizeMoney(raw.purchaseTotal),
        cashRefund: quantizeMoney(raw.cashRefund),
        // Counts
        due: quantizeMoney(raw.due),
        orderCount: raw.orderCount,
        expenseCount: raw.expenseCount,
        returnCount: raw.returnCount,
        collectionCount: raw.collectionCount,
        purchaseCount: raw.purchaseCount,
      };
    };

    // A cell nothing was found for — every field zero, and the shape the
    // accumulator below starts from. Built from `cellFor` with a month key no
    // bucket can produce, so the zero row can never drift from the real one.
    const emptyRaw = () => cellFor('none', 'none');
    const addRaw = (acc, raw) => {
      for (const f of Object.keys(raw)) acc[f] = (acc[f] || 0) + raw[f];
      return acc;
    };

    // Every month in the window, including the ones with no trade at all. A gap
    // in the rows would read as "no data" when what it means is "we sold
    // nothing", and those are different answers to the owner's question.
    const monthKeys = [];
    for (let y = fromYear, m = fromMon; y < toYear || (y === toYear && m <= toMon);) {
      monthKeys.push(`${y}-${String(m).padStart(2, '0')}`);
      m += 1;
      if (m > 12) { m = 1; y += 1; }
    }

    const shopTotalRaw = emptyRaw();
    const months = monthKeys.map((month) => {
      // Shop-wide for the month. Summed from the branch cells when the shop is
      // split, so the row and the columns beneath it cannot disagree; read
      // straight from the books when it is not.
      const raw = withBranchBreakdown
        ? branchIds.reduce((acc, id) => addRaw(acc, cellFor(month, id)), emptyRaw())
        : cellFor(month, null);
      addRaw(shopTotalRaw, raw);
      return {
        ...present(month, raw),
        ...(withBranchBreakdown
          ? {
            branches: branchIds.map((id) => ({
              branchId: id,
              branchName: branchNames.get(id) || 'বন্ধ শাখা',
              ...present(month, cellFor(month, id)),
            })),
          }
          : {}),
      };
    });

    /**
     * The per-branch totals for the WHOLE window — the "which branch is
     * carrying it" answer, which is the reason a multi-branch shop opens this
     * report at all.
     */
    const byBranch = withBranchBreakdown
      ? branchIds.map((id) => {
        const raw = monthKeys.reduce((acc, month) => addRaw(acc, cellFor(month, id)), emptyRaw());
        return {
          branchId: id,
          branchName: branchNames.get(id) || 'বন্ধ শাখা',
          // Whether this branch still exists. The client greys a closed
          // branch's column rather than hiding it: its history is real and the
          // shop total includes it.
          isActive: branchNames.has(id),
          ...present('total', raw),
          months: monthKeys.map((month) => present(month, cellFor(month, id))),
        };
      })
      : [];

    const result = {
      from,
      to,
      // Whether the branch dimension is present at all, so the client does not
      // have to infer it from an empty array — a single-branch shop and a
      // multi-branch shop with no trade in the window would look identical.
      multiBranch: withBranchBreakdown,
      months,
      byBranch,
      total: present('total', shopTotalRaw),
    };

    await cacheService.set(cacheKey, result, getTTL.monthWise);
    return result;
  }

  /**
   * The reporting window, resolved.
   *
   * Defaults to the last 12 months ENDING WITH THE CURRENT ONE — an owner
   * opening this in September wants September at the bottom, not August. The
   * current month is partial by definition and is labelled as such by the
   * client rather than excluded: leaving it out would make the report unable to
   * answer "how are we doing this month", which is half of why it is open.
   *
   * Clamped to 36 months. The pipeline cost is flat in the window but the
   * PAYLOAD is not — 36 months across six branches is already ~250 cells — and
   * an unbounded `months=9999` is a cheap way to make the server assemble a
   * response nobody asked for.
   */
  _monthWindow({ from, to, months } = {}) {
    const MAX_MONTHS = 36;
    const valid = (m) => typeof m === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(m);

    // `getUTC*` on a shifted timestamp, not `getFullYear` on a local one: the
    // server's own zone is not Dhaka's and must not decide which month "now"
    // falls in. Same construction as getDateWiseSummary's.
    const bdNow = new Date(Date.now() + BD_OFFSET_MS);
    const nowKey = `${bdNow.getUTCFullYear()}-${String(bdNow.getUTCMonth() + 1).padStart(2, '0')}`;

    let end = valid(to) ? to : nowKey;
    let start = valid(from) ? from : null;

    if (!start) {
      const n = Math.min(MAX_MONTHS, Math.max(1, Number(months) || 12));
      const [ey, em] = end.split('-').map(Number);
      const d = new Date(Date.UTC(ey, em - 1 - (n - 1), 1));
      start = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
    }

    // A reversed range is a typo, not a request for zero rows.
    if (start > end) [start, end] = [end, start];

    // Trimmed from the START, so a too-wide range keeps the RECENT months. An
    // owner who asks for ten years wants this year and last, not 2016.
    const span = (a, b) => {
      const [ay, am] = a.split('-').map(Number);
      const [by, bm] = b.split('-').map(Number);
      return (by - ay) * 12 + (bm - am) + 1;
    };
    if (span(start, end) > MAX_MONTHS) {
      const [ey, em] = end.split('-').map(Number);
      const d = new Date(Date.UTC(ey, em - 1 - (MAX_MONTHS - 1), 1));
      start = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
    }

    return { from: start, to: end };
  }

  /**
   * Get all sales for a specific date (drill-down).
   *
   * `options.staffId` narrows the day to one salesperson, which is what the
   * staff report drills into. Expenses are deliberately left out of that view:
   * an expense belongs to the shop, not to whoever happened to be at the till,
   * so attributing the day's rent to one employee would make their "আসল আয়"
   * a number that means nothing. When the day is staff-scoped the expense
   * totals come back as zero and the caller shows sales figures only.
   *
   * `options.includeExpenses` attaches the ROWS behind the খরচ total, not just
   * the total. It is a separate flag rather than something this method decides
   * for itself because the decision is a permission one — the route is gated
   * `reports.view` and the rows need `expenses.view` — and the service does not
   * see `req`. The controller passes `canViewExpenses(req)`; see the note on
   * that helper for why the rows cannot simply be stripped afterwards.
   */
  async getSalesByDate(shopId, dateStr, branchId = null, options = {}) {
    const { startOfDay, endOfDay } = getBangladeshDayRange(dateStr);
    const staffId = options.staffId ? new mongoose.Types.ObjectId(options.staffId) : null;

    const dayMatch = {
      ...this._baseMatch(shopId, branchId),
      createdAt: { $gte: startOfDay, $lte: endOfDay },
    };
    if (staffId) dayMatch.createdBy = staffId;

    // Rows only when the caller may see them AND the day is not staff-scoped —
    // the same `!staffId` condition the expense TOTAL below is already keyed
    // on, so the list can never disagree with the number it itemises.
    const wantExpenseRows = options.includeExpenses === true && !staffId;

    const [sales, summary, expenseTotal, returnTotal, collectionTotal, purchaseTotal,
      expenseRows, staff] = await Promise.all([
      Sale.find(dayMatch)
        .populate('customer', 'name phone')
        .populate('createdBy', 'name')
        .sort({ createdAt: -1 })
        .lean(),

      // Gross and as-invoiced — see the DAY-STABLE ACCOUNTING note at the top
      // of this file. The day's returns are booked separately below, on the day
      // they arrived, so netting them here as well would deduct them twice.
      Sale.aggregate([
        { $match: { ...dayMatch, ...invoicedOnDayMatch() } },
        {
          $group: {
            _id: null,
            totalSales: { $sum: grossSaleAmountExpr() },
            totalProfit: { $sum: grossProfitExpr() },
            totalPaid: { $sum: '$paid' },
            totalDue: { $sum: '$due' },
            count: { $sum: 1 },
          },
        },
      ]),

      staffId
        ? Promise.resolve([])
        : Expense.aggregate([
            {
              $match: {
                ...this._baseMatch(shopId, branchId),
                date: { $gte: startOfDay, $lte: endOfDay },
              },
            },
            {
              $group: {
                _id: null,
                total: { $sum: '$amount' },
                count: { $sum: 1 },
              },
            },
          ]),

      // The day's other three books. Staff-scoped days get none of them, for
      // the same reason they get no expense total: rent, a supplier payment and
      // a customer's old due belong to the shop, not to whoever was at the till.
      staffId
        ? Promise.resolve([])
        : SalesReturn.aggregate([
            {
              $match: {
                ...this._baseMatch(shopId, branchId),
                createdAt: { $gte: startOfDay, $lte: endOfDay },
              },
            },
            {
              $group: {
                _id: null,
                returnAmount: { $sum: '$totalAmount' },
                returnProfitLoss: { $sum: '$profitReduction' },
                cashRefund: {
                  $sum: {
                    $cond: [
                      {
                        $and: [
                          { $eq: ['$refundMethod', 'cash'] },
                          { $eq: ['$refundStatus', 'settled'] },
                        ],
                      },
                      '$totalAmount',
                      0,
                    ],
                  },
                },
                count: { $sum: 1 },
              },
            },
          ]),

      staffId
        ? Promise.resolve([])
        : Payment.aggregate([
            {
              $match: {
                ...this._baseMatch(shopId, branchId),
                type: 'due_collection',
                ...LIVE_PAYMENT,
                ...paidAtMatch({ $gte: startOfDay, $lte: endOfDay }),
              },
            },
            { $group: { _id: null, collected: { $sum: '$amount' }, count: { $sum: 1 } } },
          ]),

      staffId
        ? Promise.resolve([])
        : Purchase.aggregate([
            {
              $match: {
                ...this._baseMatch(shopId, branchId),
                status: { $ne: 'cancelled' },
                date: { $gte: startOfDay, $lte: endOfDay },
              },
            },
            {
              $group: {
                _id: null,
                purchasePaid: { $sum: '$paid' },
                purchaseTotal: { $sum: '$totalAmount' },
                count: { $sum: 1 },
              },
            },
          ]),

      wantExpenseRows
        ? Expense.find({
            ...this._baseMatch(shopId, branchId),
            date: { $gte: startOfDay, $lte: endOfDay },
          })
            .populate('category', 'name icon')
            .populate('createdBy', 'name')
            .sort({ date: -1, createdAt: -1 })
            .lean()
        : Promise.resolve([]),

      // Scoped to the shop, so one shop cannot drill into another's staff by
      // guessing an id — the sale match already enforces it, but the identity
      // echoed back in the response must be held to the same rule.
      staffId
        ? User.findOne({ _id: staffId, shop: shopId }).select('name phone isOwner role').populate('role', 'name').lean()
        : Promise.resolve(null),
    ]);

    if (staffId && !staff) {
      const err = new Error('Staff member not found');
      err.statusCode = 404;
      err.messageBn = 'কর্মচারী পাওয়া যায়নি';
      // Operational, so the production error handler sends the Bengali sentence
      // above rather than the generic "কিছু একটা সমস্যা হয়েছে".
      err.isOperational = true;
      throw err;
    }

    const summaryData = summary[0] || {
      totalSales: 0,
      totalProfit: 0,
      totalPaid: 0,
      totalDue: 0,
      count: 0,
    };
    const expenseData = expenseTotal[0] || { total: 0, count: 0 };
    const returnData = returnTotal[0] || { returnAmount: 0, returnProfitLoss: 0, cashRefund: 0, count: 0 };
    const collectionData = collectionTotal[0] || { collected: 0, count: 0 };
    const purchaseData = purchaseTotal[0] || { purchasePaid: 0, purchaseTotal: 0, count: 0 };

    // The day's two books. See DAY-STABLE ACCOUNTING at the top of this file
    // for why performance and cash are reported as two numbers and not one.
    const cashIn = quantizeMoney(summaryData.totalPaid + collectionData.collected);
    const cashOut = quantizeMoney(
      expenseData.total + purchaseData.purchasePaid + returnData.cashRefund
    );

    return {
      date: dateStr,
      staff: staff
        ? {
            staffId: String(staff._id),
            name: staff.name,
            phone: staff.phone || null,
            roleName: staff.isOwner ? 'Owner' : staff.role?.name || null,
            isOwner: staff.isOwner === true,
          }
        : null,
      sales,
      // Absent (not empty) when the caller may not see them, so the UI can tell
      // "no expenses that day" apart from "not allowed to know" and does not
      // render an empty খরচ তালিকা over a day that had five.
      expenses: wantExpenseRows ? expenseRows : null,
      summary: {
        ...summaryData,

        // ── Performance ──────────────────────────────────────────────────
        totalReturns: returnData.returnAmount,
        returnCount: returnData.count,
        netSales: quantizeMoney(summaryData.totalSales - returnData.returnAmount),
        returnsLoss: returnData.returnProfitLoss,
        totalExpenses: expenseData.total,
        expenseCount: expenseData.count,
        // Renamed from `netEarnings`, which read as "the money we actually
        // made" while computing something that can be positive on a day the
        // drawer went backwards. This is profit; `netCash` below is the money.
        netProfit: quantizeMoney(
          summaryData.totalProfit - returnData.returnProfitLoss - expenseData.total
        ),

        // ── Cash ─────────────────────────────────────────────────────────
        cashIn,
        cashOut,
        netCash: quantizeMoney(cashIn - cashOut),
        salesPaid: summaryData.totalPaid,
        collected: collectionData.collected,
        collectionCount: collectionData.count,
        purchasePaid: purchaseData.purchasePaid,
        purchaseTotal: purchaseData.purchaseTotal,
        purchaseCount: purchaseData.count,
        cashRefund: returnData.cashRefund,

        // Gross per invoice, matching `totalSales` above — dividing the NET of
        // a day's returns by the day's order count would understate the basket
        // of a day whose returns came off invoices written on some other day.
        averageOrderValue:
          summaryData.count > 0
            ? Math.round(summaryData.totalSales / summaryData.count)
            : 0,
      },
    };
  }

  // Get trending products (7-day vs previous 7-day comparison)
  async getTrendingProducts(shopId, options = {}, branchId = null) {
    const { period = 7, limit = 20 } = options;

    const now = new Date();
    const currentStart = new Date(now);
    currentStart.setDate(now.getDate() - period);
    const previousStart = new Date(currentStart);
    previousStart.setDate(currentStart.getDate() - period);

    // Get sales for current period and previous period
    const [currentPeriod, previousPeriod] = await Promise.all([
      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            createdAt: { $gte: currentStart, $lte: now },
          },
        },
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.product',
            productName: { $first: '$items.productName' },
            totalQuantity: { $sum: '$items.quantity' },
            totalRevenue: { $sum: '$items.total' },
            salesCount: { $sum: 1 },
          },
        },
        roundQtyStage,
        { $sort: { totalRevenue: -1 } },
      ]),

      Sale.aggregate([
        {
          $match: {
            ...this._baseMatch(shopId, branchId),
            status: { $ne: 'cancelled' },
            createdAt: { $gte: previousStart, $lt: currentStart },
          },
        },
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.product',
            productName: { $first: '$items.productName' },
            totalQuantity: { $sum: '$items.quantity' },
            totalRevenue: { $sum: '$items.total' },
          },
        },
        roundQtyStage,
      ]),
    ]);

    // Create lookup map for previous period
    const previousMap = new Map();
    for (const p of previousPeriod) {
      previousMap.set(p._id.toString(), p);
    }

    // Calculate trends
    const products = currentPeriod.map((curr) => {
      const prev = previousMap.get(curr._id.toString());
      const prevQty = prev?.totalQuantity || 0;
      const prevRevenue = prev?.totalRevenue || 0;

      let growthPercent = 0;
      if (prevQty > 0) {
        growthPercent = ((curr.totalQuantity - prevQty) / prevQty) * 100;
      } else if (curr.totalQuantity > 0) {
        growthPercent = 100; // New entry
      }

      let trend = 'stable';
      if (!prev) trend = 'new';
      else if (growthPercent > 10) trend = 'rising';
      else if (growthPercent < -10) trend = 'declining';

      return {
        productId: curr._id,
        productName: curr.productName,
        currentPeriodQty: roundReportQty(curr.totalQuantity),
        previousPeriodQty: prevQty,
        currentRevenue: curr.totalRevenue,
        previousRevenue: prevRevenue,
        growthPercent: Math.round(growthPercent),
        // Already rounded to 1 dp — divisions like 100/3 are exactly where a
        // "৩৩.৩৩৩৩৩৩৩৩৩৩৩" reaches the screen.
        velocity: Math.round((curr.totalQuantity / period) * 10) / 10,
        salesCount: curr.salesCount,
        trend,
      };
    });

    // Also check for declining products (were in previous but not in current)
    const currentIds = new Set(currentPeriod.map((c) => c._id.toString()));
    const declining = previousPeriod
      .filter((p) => !currentIds.has(p._id.toString()))
      .map((prev) => ({
        productId: prev._id,
        productName: prev.productName,
        currentPeriodQty: 0,
        previousPeriodQty: roundReportQty(prev.totalQuantity),
        currentRevenue: 0,
        previousRevenue: prev.totalRevenue,
        growthPercent: -100,
        velocity: 0,
        salesCount: 0,
        trend: 'declining',
      }));

    // Merge and sort
    const all = [...products, ...declining];

    // Separate by category
    const trending = all
      .filter((p) => p.trend === 'rising' || p.trend === 'new')
      .sort((a, b) => b.growthPercent - a.growthPercent)
      .slice(0, limit);

    const declinedList = all
      .filter((p) => p.trend === 'declining')
      .sort((a, b) => a.growthPercent - b.growthPercent)
      .slice(0, limit);

    const topSelling = all
      .sort((a, b) => b.currentRevenue - a.currentRevenue)
      .slice(0, limit);

    return {
      period,
      currentPeriodLabel: `Last ${period} days`,
      previousPeriodLabel: `Previous ${period} days`,
      trending,
      declining: declinedList,
      topSelling,
    };
  }

  /**
   * Staff / salesman-wise reports.
   *
   * The implementation lives in staffReport.service.js — it grew filters,
   * period comparison, a day-by-day series and per-line bill allocation, and
   * this file was already 1900 lines. These two remain as the public entry
   * points so every existing caller (controller, exportReport below) is
   * unchanged.
   */
  async getStaffReport(shopId, options = {}, branchId = null) {
    return staffReportService.getSummary(shopId, options, branchId);
  }

  async getDetailedStaffReport(shopId, options = {}, branchId = null) {
    return staffReportService.getDetailed(shopId, options, branchId);
  }

  // Export report (placeholder - implement actual export logic)
  async exportReport(shopId, type, format, options, branchId = null) {
    // This would generate actual PDF/Excel/CSV files
    // For now, return the data
    let data;
    switch (type) {
      case 'sales':
        data = await this.getSalesReport(shopId, options, branchId);
        break;
      case 'products':
        data = await this.getProductReport(shopId, options, branchId);
        break;
      case 'customers':
        data = await this.getCustomerReport(shopId, options);
        break;
      case 'staff':
        data = await this.getStaffReport(shopId, options, branchId);
        break;
      case 'staff-detailed':
        data = await this.getDetailedStaffReport(shopId, options, branchId);
        break;
      default:
        throw new Error('Invalid report type');
    }

    return data;
  }
}

module.exports = new ReportService();
